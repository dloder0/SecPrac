function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\labsetup\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools\labsetup)) {
    New-Item -Path C:\Tools\labsetup -ItemType Directory
}

$needReboot = $false

$Computername = $env:COMPUTERNAME
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for startup task")
$Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
if ($null -eq $Task) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Startup task was not found")
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating startup task")
    $taskTrigger = New-ScheduledTaskTrigger -AtStartup
    $taskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\Tools\labsetup\$Computername.ps1" -WorkingDirectory 'c:\tools\labsetup'
    $taskPrincipal = New-ScheduledTaskPrincipal -UserID "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $Task = Register-ScheduledTask 'ASDEFENDLABSETUP' -Action $taskAction -Trigger $taskTrigger -Principal $taskPrincipal
}

Set-DnsClientServerAddress 'Ether*' -ServerAddresses ('192.168.1.10')
Clear-DnsClientCache

$foundForest = $false
$loopcounter = 0
do {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for forest")
    $Ping = Test-NetConnection -ComputerName 'contoso.local'
    if ($Ping.PingSucceeded) {
            $foundForest = $true
    } else {
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    }
    Clear-DnsClientCache
} while (!($foundForest))

$foundLDAP = $false
$loopcounter = 0
do {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for domain controller response")
    $Ping = Test-NetConnection -ComputerName 'contoso.local' -Port 389
    if ($Ping.TcpTestSucceeded) {
            $foundLDAP = $true
    } else {
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    }
    Clear-DnsClientCache
} while (!($foundLDAP))

$CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current Domain is $CurrentDomain")
if ($CurrentDomain -eq 'contoso.local') {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Joined to contoso.local")
} else {
    $joinCred = New-Object pscredential -ArgumentList ([pscustomobject]@{
        UserName = $null
        Password = (ConvertTo-SecureString -String 'TempJoinPA$$' -AsPlainText -Force)[0]
    })
    $addComputerSplat = @{
        DomainName = 'contoso.local'
        Options = 'UnsecuredJoin', 'PasswordPass'
        Credential = $joinCred
    }
    $loopcounter = 0
    $joinsucceeded = $false
    do {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Joining contoso.local")
        $Error.Clear()
        Add-Computer @addComputerSplat
        if ($Error.count -gt 0) {
            CreateAuditOutput ($Error[0].ToString())
        } else {
            $joinsucceeded = $true
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Join successful")
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Rebooting")
            $needReboot = $true
        }
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    } while (!($joinsucceeded))
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)

if ($needReboot) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Rebooting")
    restart-computer -Force
} else {
    $Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
    if ($null -ne $Task) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Deleting setup task")
        Unregister-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -Confirm:$false
    }
}
