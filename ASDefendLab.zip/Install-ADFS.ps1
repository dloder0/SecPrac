#############
 
ADFS
 
<#
.SYNOPSIS
    Deploys Active Directory Federation Services (AD FS) 
    in the contoso.local domain with a Group Managed Service Account (gMSA).
 
.NOTES
    Run as Domain Administrator on a domain-joined Windows Server
    Tested on Windows Server 2019/2022
#>
 
# -------------------------------
# Variables
# -------------------------------
$DomainName        = "contoso.local"
$ADFSSiteName      = "fs.contoso.local"       # Federation Service FQDN (must match certificate)
$ADFSDisplayName   = "Contoso Federation Service"
$GmsaName          = "ADFSgmsa"               # Name of the gMSA
$CertFriendlyName  = "ContosoADFS"
 
# -------------------------------
# Step 1: Install Required Features
# -------------------------------
Write-Host "Installing AD FS role and RSAT AD tools..." -ForegroundColor Cyan
Install-WindowsFeature ADFS-Federation -IncludeManagementTools -Verbose
Install-WindowsFeature RSAT-AD-PowerShell -Verbose
 
# -------------------------------
# Step 2: Create KDS Root Key (if first gMSA in forest)
# -------------------------------
if (-not (Get-KdsRootKey)) {
    Write-Host "Creating KDS root key (may take up to 10 hours to replicate in production)..." -ForegroundColor Cyan
    Add-KdsRootKey -EffectiveTime ((Get-Date).AddHours(-10))
}
 
# -------------------------------
# Step 3: Create the gMSA account
# -------------------------------
Write-Host "Creating gMSA account $GmsaName..." -ForegroundColor Cyan
$ComputerName = $env:COMPUTERNAME + "$"   # Current server (AD FS host) as allowed principal
New-ADServiceAccount -Name $GmsaName -DNSHostName $ADFSSiteName -PrincipalsAllowedToRetrieveManagedPassword $ComputerName
 
# Install the gMSA on this computer
Write-Host "Installing gMSA on local server..." -ForegroundColor Cyan
Install-ADServiceAccount -Identity $GmsaName
 
# Test gMSA installation
if (Test-ADServiceAccount $GmsaName) {
    Write-Host "gMSA $GmsaName is installed and working." -ForegroundColor Green
} else {
    Write-Host "ERROR: gMSA $GmsaName failed to install." -ForegroundColor Red
    exit 1
}
 
# -------------------------------
# Step 4: Create SSL Certificate
# -------------------------------
Write-Host "Creating self-signed SSL certificate for $ADFSSiteName..." -ForegroundColor Cyan
$cert = New-SelfSignedCertificate `
    -DnsName $ADFSSiteName `
    -CertStoreLocation "Cert:\LocalMachine\My" `
    -FriendlyName $CertFriendlyName
 
$thumbprint = $cert.Thumbprint
 
# -------------------------------
# Step 5: Configure AD FS Farm
# -------------------------------
Write-Host "Configuring AD FS farm..." -ForegroundColor Cyan
Import-Module ADFS
 
Install-AdfsFarm `
    -CertificateThumbprint $thumbprint `
    -FederationServiceDisplayName $ADFSDisplayName `
    -FederationServiceName $ADFSSiteName `
    -GroupServiceAccountIdentifier "$DomainName\$GmsaName$" `
    -OverwriteConfiguration `
    -Verbose
 
# -------------------------------
# Step 6: Restart AD FS
# -------------------------------
Restart-Service adfssrv
 
Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "AD FS deployment completed successfully!" -ForegroundColor Green
Write-Host "Federation Service Name: $ADFSSiteName" -ForegroundColor Green
Write-Host "Display Name: $ADFSDisplayName" -ForegroundColor Green
Write-Host "gMSA Account: $DomainName\$GmsaName$" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green

 
############################