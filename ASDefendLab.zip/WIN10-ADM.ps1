function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\labsetup\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools\labsetup)) {
    New-Item -Path C:\Tools\labsetup -ItemType Directory
}

$needReboot = $false

$Computername = $env:COMPUTERNAME
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for startup task")
$Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
if ($null -eq $Task) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Startup task was not found")
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating startup task")
    $taskTrigger = New-ScheduledTaskTrigger -AtStartup
    $taskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\Tools\labsetup\$Computername.ps1" -WorkingDirectory 'c:\tools\labsetup'
    $taskPrincipal = New-ScheduledTaskPrincipal -UserID "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $Task = Register-ScheduledTask 'ASDEFENDLABSETUP' -Action $taskAction -Trigger $taskTrigger -Principal $taskPrincipal
}

$RSATTools = @()
$RSATTools += 'Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0'
$RSATTools += 'Rsat.Dns.Tools~~~~0.0.1.0'
$RSATTools += 'Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0'
$RSATTools += 'Rsat.ServerManager.Tools~~~~0.0.1.0'

ForEach ($RSATTool in $RSATTools) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for $RSATTool")
    $State = (Get-WindowsCapability -Name $RSATTool -Online).State
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
    if ($State -ne 'Installed') {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing $RSATTool")
        try {
            Add-WindowsCapability -Online -Name $RSATTool
            $needReboot = $true
        } catch {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
        }
    }
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for NuGet")
$State = Get-PackageProvider -ListAvailable | Where-Object -Property Name -eq 'NuGet'
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if ($null -eq $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing NuGet")
    try {
        Get-PackageProvider -Name 'NuGet' -Force
        $needReboot = $true
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + $State.version)
}


CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for ExchangeOnlineManagement")
$State = Get-InstalledModule -Name ExchangeOnlineManagement
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if ($null -eq $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing ExchangeOnlineManagement")
    try {
        Install-Module -Name ExchangeOnlineManagement -Force
        $needReboot = $true
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + $State.version)
}


CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for WinSCP")
$State = Get-Package -Name WinSCP
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if ($null -eq $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing WinSCP")
    try {
        Install-Package -Name WinSCP -Force
        $needReboot = $true
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + $State.version)
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for WinSCP shortcut")
if (Test-Path -PathType Leaf -Path 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\WinSCP.lnk') {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Found WinSCP shortcut at C:\ProgramData\Microsoft\Windows\Start Menu\Programs\WinSCP.lnk")
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating WinSCP shortcut")
    $WinSCPversion = (get-package -Name winscp).version
    $WScriptShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WScriptShell.CreateShortcut($env:programdata + "\Microsoft\Windows\Start Menu\Programs\WinSCP.lnk")
    $Shortcut.TargetPath = $env:programfiles + "\WindowsPowerShell\Modules\WinSCP\$WinSCPversion\bin\WinSCP.exe"
    $Shortcut.Save()
    $needReboot = $true
}




Set-DnsClientServerAddress 'Ether*' -ServerAddresses ('192.168.1.10')
Clear-DnsClientCache

$foundForest = $false
$loopcounter = 0
do {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for forest")
    $Ping = Test-NetConnection -ComputerName 'contoso.local'
    if ($Ping.PingSucceeded) {
            $foundForest = $true
    } else {
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    }
    Clear-DnsClientCache
} while (!($foundForest))

$foundLDAP = $false
$loopcounter = 0
do {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for domain controller response")
    $Ping = Test-NetConnection -ComputerName 'contoso.local' -Port 389
    if ($Ping.TcpTestSucceeded) {
            $foundLDAP = $true
    } else {
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    }
    Clear-DnsClientCache
} while (!($foundLDAP))

$CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current Domain is $CurrentDomain")
if ($CurrentDomain -eq 'contoso.local') {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Joined to contoso.local")
} else {
    $joinCred = New-Object pscredential -ArgumentList ([pscustomobject]@{
        UserName = $null
        Password = (ConvertTo-SecureString -String 'TempJoinPA$$' -AsPlainText -Force)[0]
    })
    $addComputerSplat = @{
        DomainName = 'contoso.local'
        Options = 'UnsecuredJoin', 'PasswordPass'
        Credential = $joinCred
    }
    $loopcounter = 0
    $joinsucceeded = $false
    do {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Joining contoso.local")
        $Error.Clear()
        Add-Computer @addComputerSplat
        if ($Error.count -gt 0) {
            CreateAuditOutput ($Error[0].ToString())
        } else {
            $joinsucceeded = $true
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Join successful")
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Rebooting")
            $needReboot = $true
        }
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    } while (!($joinsucceeded))
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)

if ($needReboot) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Rebooting")
    restart-computer -Force
} else {
    $Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
    if ($null -ne $Task) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Deleting setup task")
        Unregister-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -Confirm:$false
    }
}
