function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\labsetup\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools\labsetup)) {
    New-Item -Path C:\Tools\labsetup -ItemType Directory
}

$convertEvilGenixCookiesScript = @'
function Read-MultiLineInputBoxDialog([string]$Message, [string]$WindowTitle, [string]$DefaultText)
{
<#
    .SYNOPSIS
    Prompts the user with a multi-line input box and returns the text they enter, or null if they cancelled the prompt.

    .DESCRIPTION
    Prompts the user with a multi-line input box and returns the text they enter, or null if they cancelled the prompt.

    .PARAMETER Message
    The message to display to the user explaining what text we are asking them to enter.

    .PARAMETER WindowTitle
    The text to display on the prompt window's title.

    .PARAMETER DefaultText
    The default text to show in the input box.

    .EXAMPLE
    $userText = Read-MultiLineInputDialog "Input some text please:" "Get User's Input"

    Shows how to create a simple prompt to get mutli-line input from a user.

    .EXAMPLE
    # Setup the default multi-line address to fill the input box with.
    $defaultAddress = @'
    John Doe
    123 St.
    Some Town, SK, Canada
    A1B 2C3
    '@

    $address = Read-MultiLineInputDialog "Please enter your full address, including name, street, city, and postal code:" "Get User's Address" $defaultAddress
    if ($address -eq $null)
    {
        Write-Error "You pressed the Cancel button on the multi-line input box."
    }

    Prompts the user for their address and stores it in a variable, pre-filling the input box with a default multi-line address.
    If the user pressed the Cancel button an error is written to the console.

    .EXAMPLE
    $inputText = Read-MultiLineInputDialog -Message "If you have a really long message you can break it apart`nover two lines with the powershell newline character:" -WindowTitle "Window Title" -DefaultText "Default text for the input box."

    Shows how to break the second parameter (Message) up onto two lines using the powershell newline character (`n).
    If you break the message up into more than two lines the extra lines will be hidden behind or show ontop of the TextBox.

    .NOTES
    Name: Show-MultiLineInputDialog
    Author: Daniel Schroeder (originally based on the code shown at http://technet.microsoft.com/en-us/library/ff730941.aspx)
    Version: 1.0
#>
    Add-Type -AssemblyName System.Drawing
    Add-Type -AssemblyName System.Windows.Forms

    # Create the Label.
    $label = New-Object System.Windows.Forms.Label
    $label.Location = New-Object System.Drawing.Size(10,10)
    $label.Size = New-Object System.Drawing.Size(280,20)
    $label.AutoSize = $true
    $label.Text = $Message

    # Create the TextBox used to capture the user's text.
    $textBox = New-Object System.Windows.Forms.TextBox
    $textBox.Location = New-Object System.Drawing.Size(10,40)
    $textBox.Size = New-Object System.Drawing.Size(575,200)
    $textBox.AcceptsReturn = $true
    $textBox.AcceptsTab = $false
    $textBox.Multiline = $true
    $textBox.ScrollBars = 'Both'
    $textBox.Text = $DefaultText

    # Create the OK button.
    $okButton = New-Object System.Windows.Forms.Button
    $okButton.Location = New-Object System.Drawing.Size(415,250)
    $okButton.Size = New-Object System.Drawing.Size(75,25)
    $okButton.Text = "OK"
    $okButton.Add_Click({ $form.Tag = $textBox.Text; $form.Close() })

    # Create the Cancel button.
    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Location = New-Object System.Drawing.Size(510,250)
    $cancelButton.Size = New-Object System.Drawing.Size(75,25)
    $cancelButton.Text = "Cancel"
    $cancelButton.Add_Click({ $form.Tag = $null; $form.Close() })

    # Create the form.
    $form = New-Object System.Windows.Forms.Form
    $form.Text = $WindowTitle
    $form.Size = New-Object System.Drawing.Size(610,320)
    $form.FormBorderStyle = 'FixedSingle'
    $form.StartPosition = "CenterScreen"
    $form.AutoSizeMode = 'GrowAndShrink'
    $form.Topmost = $True
    $form.AcceptButton = $okButton
    $form.CancelButton = $cancelButton
    $form.ShowInTaskbar = $true

    # Add all of the controls to the form.
    $form.Controls.Add($label)
    $form.Controls.Add($textBox)
    $form.Controls.Add($okButton)
    $form.Controls.Add($cancelButton)

    # Initialize and show the form.
    $form.Add_Shown({$form.Activate()})
    [void] $form.ShowDialog()  # Trash the text of the button that was clicked.

    # Return the text that the user entered.
    return $form.Tag
}

$multiLineText = Read-MultiLineInputBoxDialog -Message "Paste Bastion clipboard content here..." -WindowTitle "EvilGenix Cookies" -DefaultText ""

$cleaned = $multiLineText -replace "`r`n", "" -replace "`n", "" -replace "`r", ""

$jsonContent = $cleaned | ConvertFrom-Json

$ESTSAuth = ($jsonContent | Where-Object { $_.name -eq 'ESTSAUTH'}).value
$ESTSAuthPersistent = ($jsonContent | Where-Object { $_.name -eq 'ESTSAUTHPERSISTENT'}).value

Add-Type -AssemblyName PresentationFramework

# Create the window
$window = New-Object System.Windows.Window
$window.Title = "Captured Cookies"
$window.Width = 800
$window.Height = 400
$window.WindowStartupLocation = "CenterScreen"

# Create a StackPanel to hold the content
$stackPanel = New-Object System.Windows.Controls.StackPanel
$stackPanel.Margin = '10'


# Create Label1
$Label1= New-Object System.Windows.Controls.TextBox
$Label1.Text = "ESTSAUTH"
$Label1.IsReadOnly = $true
$Label1.IsTabStop = $false
$Label1.BorderThickness = 0

# Create Label2
$Label2= New-Object System.Windows.Controls.TextBox
$Label2.Text = "ESTSAUTHPERSISTENT"
$Label2.IsReadOnly = $true
$Label2.IsTabStop = $false
$Label2.BorderThickness = 0

# Create two read-only TextBoxes for the strings
$textBox1 = New-Object System.Windows.Controls.TextBox
$textBox1.Text = $ESTSAuth
$textBox1.IsReadOnly = $true
$textBox1.TextWrapping = "Wrap"
$textBox1.Margin = '0,0,0,10'

$textBox2 = New-Object System.Windows.Controls.TextBox
$textBox2.Text = $ESTSAuthPersistent
$textBox2.IsReadOnly = $true
$textBox2.TextWrapping = "Wrap"
$textBox2.Margin = '0,0,0,10'

# Add the TextBoxes to the StackPanel
$stackPanel.Children.Add($label1)
$stackPanel.Children.Add($textBox1)
$stackPanel.Children.Add($label2)
$stackPanel.Children.Add($textBox2)

# Set the content of the window
$window.Content = $stackPanel

# Show the window
[void] $window.ShowDialog()
'@

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)


CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for PowerShell 7")
$state = $null
$State = Get-ItemProperty -Path HKLM:\Software\Microsoft\PowerShellCore\InstallerProperty -Name InstallFolder
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if ($null -eq $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing PowerShell 7")
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Determine current download source")
    $repoApi = "https://api.github.com/repos/PowerShell/PowerShell/releases"
    $assetPattern = "win-x64.msi"
    $releases = Invoke-RestMethod -Uri $repoApi -Headers @{ "User-Agent" = "PowerShellScript" }
    # Filter for GA releases only (exclude preview, rc, beta)
    $gaReleases = $releases | Where-Object { $_.prerelease -eq $false } | Where-Object { $_.tag_name -notmatch "preview|rc|beta" }
    $latest = $gaReleases | Sort-Object -Property published_at -Descending | Select-Object -First 1
    $asset = $latest.assets | Where-Object { $_.name -like "*$assetPattern*" } | Select-Object -First 1
    $downloadUrl = $asset.browser_download_url
    $filename = $asset.name
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Downloading PowerShell 7 from $downloadURL")

    try {
        Invoke-WebRequest -Uri $downloadURL -OutFile $env:TEMP\$filename -UseBasicParsing
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }

    $msiPath = $env:TEMP + "\" + $filename
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing PowerShell 7 from $msiPath")
    $process = Start-Process -Wait -FilePath msiexec -ArgumentList '/i', $msiPath, '/quiet' -PassThru
    if ($process.ExitCode -ne 0) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($process.ExitCode))
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }

}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for Convert Evil Genix Cookies script")
$state = $null
$State = Test-Path -Path c:\tools\convert-EvilGenixCookies.ps1 -PathType Leaf
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if (-not $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Saving the Convert Evil Genix Cookies script")
    $convertEvilGenixCookiesScript | Out-File -FilePath c:\tools\convert-EvilGenixCookies.ps1
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for NuGet")
$state = $null
$State = Get-PackageProvider -ListAvailable | Where-Object -Property Name -eq 'NuGet'
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if ($null -eq $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing NuGet")
    try {
        Get-PackageProvider -Name 'NuGet' -Force
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + $State.version)
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for Az")
$state = $null
$State = Get-InstalledModule -Name Az
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if ($null -eq $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing Az")
    try {
        Install-Module -Name Az -Force
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + $State.version)
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for Microsoft.Graph")
$state = $null
$State = Get-InstalledModule -Name Microsoft.Graph
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
if ($null -eq $State) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing Microsoft.Graph")
    try {
        Install-Module -Name Microsoft.Graph -Force
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + $State.version)
}


CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)
