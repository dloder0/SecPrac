############################################
<# 
.SYNOPSIS
    Deploys Active Directory Certificate Services (AD CS) as an Enterprise Root CA 
    in the contoso.local domain.
 
.NOTES
    Run as Domain Administrator
    Works on Windows Server 2016/2019/2022
#>
 
# ADCS
# Variables
$DomainName = "contoso.local"
$CACommonName = "Contoso-RootCA"
$CADistinguishedNameSuffix = "DC=contoso,DC=local"
$CAInstallFolder = "C:\CA"
 
# Ensure ADCS and Management Tools are installed
Write-Host "Installing AD CS Role and Management Tools..." -ForegroundColor Cyan
Install-WindowsFeature AD-Certificate -IncludeManagementTools -Verbose
 
# Install ADCS Certification Authority Role Service
Write-Host "Installing AD CS Certification Authority..." -ForegroundColor Cyan
Install-AdcsCertificationAuthority `
    -CAType EnterpriseRootCA `
    -CACommonName $CACommonName `
    -KeyLength 2048 `
    -HashAlgorithmName SHA256 `
    -ValidityPeriod Years `
    -ValidityPeriodUnits 10 `
    -CryptoProviderName "RSA#Microsoft Software Key Storage Provider" `
    -Force
 
# Configure the CA Database and Logs
Write-Host "Configuring CA Database and Log Locations..." -ForegroundColor Cyan
certutil -setreg CA\DSConfigDN "CN=Configuration,$CADistinguishedNameSuffix"
certutil -setreg CA\LogDir "$CAInstallFolder\Logs"
certutil -setreg CA\DBDirectory "$CAInstallFolder\Database"
certutil -setreg CA\PolicyModules\CertificateAuthority_MicrosoftDefault.Policy\EditFlags +EDITF_ATTRIBUTESUBJECTALTNAME2
 
# Restart Certificate Services to apply changes
Write-Host "Restarting Certificate Services..." -ForegroundColor Cyan
Restart-Service CertSvc
 
Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "Active Directory Certificate Services deployment complete!" -ForegroundColor Green
Write-Host "Certification Authority: $CACommonName" -ForegroundColor Green
Write-Host "Domain: $DomainName" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green

 
 
############################################