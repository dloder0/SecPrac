function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools)) {
    New-Item -Path C:\Tools -ItemType Directory
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking current role")
$CurrentRole = (Get-CimInstance -ClassName Win32_OperatingSystem).ProductType
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current role is $CurrentRole")

$Computers = @()
$Computers += 'WIN10-ADM'

if ($CurrentRole -eq '2') {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Waiting for ADDS services")
    Start-Service -Name 'NTDS'
    Start-Service -Name 'DNS'
    Start-Service -Name 'Kdc'
    Start-Service -Name 'ADWS'
    Start-Sleep -Seconds 30
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " ADDS services are running")
    $foundDC = $false
    do {
        $DC = Get-ADComputer -LDAPFilter "(&(objectClass=computer)(cn=SVR19-DC1))"
        if ($null -eq $DC) {
            Start-Sleep -Seconds 10
        } else {
            $foundDC = $true
        }
    } while (!($foundDC))
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for computer accounts")
    ForEach ($Computer in $Computers) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for $Computer")
        $CPUAccount = Get-ADComputer -LDAPFilter "(&(objectClass=computer)(cn=$Computer))"
        if ($null -eq $CPUAccount) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Did not find $Computer")
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating $Computer")
            New-ADComputer -Name $Computer -AccountPassword (ConvertTo-SecureString -String 'TempJoinPA$$' -AsPlainText -Force)
        } else {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Found $Computer")
        }
    }
    $Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
    if ($null -ne $Task) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Deleting setup task")
        Unregister-ScheduledTask -TaskName 'ASDEFENDLABSETUP'
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for startup task")
    $Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
    if ($null -eq $Task) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Startup task was not found")
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating startup task")
        $taskTrigger = New-ScheduledTaskTrigger -AtStartup
        $taskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\Tools\invoke-setup.ps1" -WorkingDirectory 'c:\tools'
        $taskPrincipal = New-ScheduledTaskPrincipal -UserID "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount -RunLevel Highest
        $Task = Register-ScheduledTask 'ASDEFENDLABSETUP' -Action $taskAction -Trigger $taskTrigger -Principal $taskPrincipal
    }
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for AD-Domain-Services feature")
    if (!(Get-WindowsFeature -Name AD-Domain-Services).Installed) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " AD-Domain-Services feature is not installed")
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Installing AD-Domain-Services feature")
        try {
            Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools
        } catch {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
            exit 1
        }
    }
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Starting promotion to DC in new forest")
    try {
        Install-ADDSForest -DomainName 'contoso.local' -SafeModeAdministratorPassword (Convertto-SecureString -AsPlainText "P@ssw0rd123!" -Force) -Force
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
        exit 1
    }
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)
