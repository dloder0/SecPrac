function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools)) {
    New-Item -Path C:\Tools -ItemType Directory
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)

Start-Sleep -Seconds 300

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended")
