function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools)) {
    New-Item -Path C:\Tools -ItemType Directory
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)


#Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking current role")
$CurrentRole = (Get-CimInstance -ClassName Win32_OperatingSystem).ProductType
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current role is $CurrentRole")

if ($CurrentRole -ne '2') {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Starting promotion to DC in new forest")
    try {
        Install-ADDSForest -DomainName 'contoso.local' -SafeModeAdministratorPassword (Convertto-SecureString -AsPlainText "P@ssw0rd123!" -Force)
    } catch {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
        exit 1
    }
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)
