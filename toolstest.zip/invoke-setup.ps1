function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools)) {
    New-Item -Path C:\Tools -ItemType Directory
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is starting")
$HostName = $env:computername
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Hostname is $HostName")

if (Test-Path -PathType Leaf -Path "c:\tools\$HostName.ps1") {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Starting setup file c:\tools\$HostName.ps1")
    & c:\tools\$HostName.ps1
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended")
