function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools)) {
    New-Item -Path C:\Tools -ItemType Directory
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is starting in " + $MyInvocation.MyCommand.Name)
$HostName = $env:computername
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Hostname is $HostName")

if (Test-Path -PathType Leaf -Path "c:\tools\$HostName.ps1") {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Starting setup file c:\tools\$HostName.ps1")
    Invoke-Expression ". c:\tools\$HostName.ps1"
}

if ($null -ne $LASTEXITCODE) {
    if ($LASTEXITCODE -ne 0) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup terminating $LASTEXITCODE")
        exit $LASTEXITCODE
    } else {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)
    }
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)
}

