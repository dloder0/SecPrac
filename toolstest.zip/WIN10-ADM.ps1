function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools)) {
    New-Item -Path C:\Tools -ItemType Directory
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)

$RSATTools = @()
$RSATTools += 'Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0'
$RSATTools += 'Rsat.Dns.Tools~~~~0.0.1.0'
$RSATTools += 'Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0'
$RSATTools += 'Rsat.ServerManager.Tools~~~~0.0.1.0'

ForEach ($RSATTool in $RSATTools) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for $RSATTool")
    $State = (Get-WindowsCapability -Name $RSATTool -Online).State
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current state is $State")
    if ($State -ne 'Installed') {
        try {
            Add-WindowsCapability -Online -Name $RSATTool
        } catch {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " " + ($Error[0] | Out-String))
        }
    }
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)
