<#PSScriptInfo

    .VERSION 2506.5.0

    .GUID bd60a339-162a-4d7a-b2a2-c78a45149312

    .AUTHOR Microsoft Incident Response

    .COMPANYNAME Microsoft Corporation

    .COPYRIGHT (c) Microsoft Corporation. All rights reserved.

    .LICENSEURI https://mit-license.org/
#>

<#
        
    .SYNOPSIS
        
        Performs Installation of MDE, AzMon, or both, including any prerequisite updates for legacy systems.
        
    .DESCRIPTION
        
        The MDE setup script can be used to onboard or offboard an endpoint manually, via GPO, or MCEM. The core functionality remains the same across each deployment option with the only difference being how the script is deployed to endpoints.
        
    .PARAMETER Onboard
        
        Triggers the Onboarding of the endpoint.
        
    .PARAMETER Offboard
        
        Triggers the Offboarding of the endpoint.
        
    .PARAMETER SwitchOrg
        
        Switches the endpoint to a new MDE tenant.
        
    .PARAMETER All
        
        Will target both Modern and legacy operating systems, which will require configuration data for both.
        
    .PARAMETER Modern
        
        Will only target Modern operating systems that have the sense agent built in and runs the on\offboarding script from the MDE portal.
        
    .PARAMETER Legacy
        
        Will only target the legacy operating systems that do not have the sense agent built-in and depends on either the OMS workspace details.
        
    .PARAMETER RemoveAgent
        
        When this flag is set, the script will attempt to remove any MDE agents that are not native to the OS or being used by any other services such as SCOM.
        
    .PARAMETER WorkspaceID
        
        The Workspace ID from the MDE portal to onboard down-level endpoints.
        
    .PARAMETER WorkspaceKey
        
        The Workspace Key from the MDE portal to onboard down-level endpoints.
        
    .PARAMETER FromWorkspaceID
        
        The Workspace ID from the MDE tenant that the endpoint should switch away from. This is used to offboard from MMA when the action is set to SwitchOrg.
        
    .PARAMETER FromOrgID
        
        The Workspace ID from the MDE tenant that the endpoint should switch away from. This is used to determine if the endpoint should be offboarded from the old tenant.
        
    .PARAMETER Proxy
        
        The proxy configuration to apply to the endpoint in the format "http://<proxyServer>:port"
        If a proxy is already configured on the endpoint, this value will be ignored, and an alternative deployment method will be required.
        
    .PARAMETER CloudType
        
        Commercial, GCC, or GGC-H. This is used to target logging in all scenarios. When targeting the MMA, this is used to set OPINSIGHTS_WORKSPACE_AZURE_CLOUD_TYPE.
        
    .PARAMETER PassiveMode
        
        Set Microsoft Defender Antivirus to passive mode to prevent problems caused by having multiple antivirus products installed on a server.
        
    .PARAMETER MigrateToUnified
        
        If the endpoint is onboarded via MMA the script will attempt to install the unified agent, offboard from MMA, and onboard with the new unified agent. If the Unified agent install or onboard fails, the endpoint will be re-onboarded with MMA.
        
    .PARAMETER ConfigurationFile
        
        Causes the script to look for a psd1 configuration file instead of using a long set of parameters.
        
    .PARAMETER ValidateConfig
        
        Validates the configuration file and will return a true if valid or false if it is not valid. If the config file is not valid, review the log file for additional details.
        
    .PARAMETER EnableMMAFallback
        
        For server 2012R2 and 2016, they can be onboarded to either the legacy MMA or the modern unified sense agent. By default the script will onboard all endpoints to the unified sense agent first. If that fails the onboarding will return a failure code. If this switch is used and the unified agent onboarding fails, the script will then attempt to onboard the endpoint to MMA. This is intended to get the most MDE coverage as fast as possible to
        support an IR engagement.
        
    .PARAMETER TagList
        
        Appends device tags to endpoints during the MDE Onboarding process. The tags in this list will be appended to any automatic tags are created for installed roles such as Domain Controller, Exchange, ADFS, etc.
        
    .PARAMETER UpdateDefenderAVAll
        
        When this switch is used, the Defender AV platform and definitions will be upgraded to the latest version on all modern endpoints. This is useful when the Defender platform has not been used or maintained within the enterprise and can quickly get the entire stack up to date.
        
    .PARAMETER DownloadUpdates
        
        This switch will download the MDE prerequisites from the public download URLs. This parameter cannot be run with any other parameters.
        
    .PARAMETER StorageAccountName
        
        The Storage Account Name from the welcome email (Starts With 'ircstc')
        
    .PARAMETER SASToken
        
        The SAS Token from the welcome email (contains 'defaultinbound')
        
    .PARAMETER WriteEventLog
        
        This will add the manifest to the Application event log (Event Id 3278) of the endpoint. This can be useful when Windows Event Forwarding (WEF) has been configured in the environment to centralize the onboarding status data.
        
    .PARAMETER RefreshFiles
        
        Setting this to $true will cause the script to redownload any On/Offboarding scripts to the endpoint if the local file hash doesn't match the file hash on the mySource environment variable.
        
    .PARAMETER ErrorCode
        
        This will translate the error code into a human readable string.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Onboard -Modern
        
        In this example the script will onboard modern devices. The default behavior is to not fallback to MMA onboarding and in this case it is not possible because there is no Workspace ID or key.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Onboard -Modern -UpdateDefenderAVAll
        
        In this example the script will onboard modern devices. In addition, the Defender AV engine and threat intel will be updated to the latest version on all devices. This is useful when Defender is not currently in use during the MDE deployment.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Onboard -All -WorkspaceID '1aa3bb05-5961-491a-a472-eac16d46b6f6' -WorkspaceKey 'workspacekeyfrommdeportal==' -CloudType 'Commercial'
        
        In this example the script will attempt to onboard both modern and legacy endpoints. For endpoints that can be onboarded via MMA and the unified agent, the unified agent will be attempted first. If the installation of the Unified agent or the onboarding script fails, MMA onboarding will be attempted.
        
        Minor updates that are required by the onboarding agent for that endpoint will be installed automatically, but major cumulative updates that are missing will cause the onboarding process to fail with an error code that indicates the missing update KB number.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Onboard -All -EnableMMAFallback -WorkspaceID '1aa3bb05-5961-491a-a472-eac16d46b6f6' -WorkspaceKey 'workspacekeyfrommdeportal==' -CloudType 'Commercial'
        
        In this example the script will attempt to onboard both modern and legacy endpoints. For endpoints that can be onboarded via MMA and the unified agent, the unified agent will be attempted first.
        
        With the EnableMMAFallback switch set, if the installation of the Unified agent or the onboarding script fails, MMA onboarding will be attempted, and the script will return an error for that endpoint.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Onboard -Legacy -WorkspaceID '1aa3bb05-5961-491a-a472-eac16d46b6f6' -WorkspaceKey 'workspacekeyfrommdeportal==' -CloudType 'Commercial' -Proxy 'http://192.168.1.1:3128'
        
        In this example the script will onboard legacy devices that meet the minimum onboarding requirements. Additionally the proxy settings will be applied if a proxy is not already configured on the endpoint.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Onboard -Modern -PassiveMode
        
        In this example the script will onboard modern endpoints (In Passive Mode) that meet the minimum onboarding requirements.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Offboard -Modern
        
        In this example the script will attempt to offboard modern endpoints from MDE. If any endpoints are onboarded via MMA, they will not be offboarded.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Offboard -All -WorkspaceID '1aa3bb05-5961-491a-a472-eac16d46b6f6'
        
        In this example the script will attempt to offboard both modern and legacy endpoints from MDE.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -Offboard -All -WorkspaceID '1aa3bb05-5961-491a-a472-eac16d46b6f6' -UninstallAgent
        
        In this example the script will attempt to offboard both modern and legacy endpoints from MDE. After the device is offboarded, the monitoring agent will be uninstalled if it is not integrated into the OS.
        
        For example, MMA would be uninstalled from the Windows 7 clients and the unified agent would be uninstalled from 2012R2, but nothing would be uninstalled from Windows 11 or Server 2019 since the sense service is integrated.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -SwitchOrg -Legacy -FromWorkspaceID '66f7a6e9-2d4c-4cff-8960-f0ea41bca4d2' -WorkspaceID '1aa3bb05-5961-491a-a472-eac16d46b6f6' -WorkspaceKey 'workspacekeyfrommdeportal==' -CloudType 'Commercial'
        
        In this example the script will attempt to switch MDE tenants using the legacy client (MMA). First the endpoint will offboard from the workspace set in -FromWorkspaceID and then onboard the endpoint to the workspace set in -WorkspaceID
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -SwitchOrg -All -FromWorkspaceID '66f7a6e9-2d4c-4cff-8960-f0ea41bca4d2' -FromOrgID '40e96cca-bab3-4cbf-b6d5-b819ce686d7e' -MigrateToUnified -WorkspaceID '1aa3bb05-5961-491a-a472-eac16d46b6f6' -WorkspaceKey 'workspacekeyfrommdeportal==' -CloudType 'Commercial'
        
        In this example the script will attempt to switch MDE tenants and migrate the MDE client from MMA to Unified if possible.
        
        * This is advanced scenario that requires additional setup to succeed
        * This assumes that all endpoints are capable of running the unified agent (Windows 10+, Server 2012 R2+)
        * The Offboarding script from the old tenant will need to be placed in the script directory named WindowsDefenderATPOffboardingScript_From.cmd
        
        The endpoint will offboard from the old MDE tenant. If it is onboarded via MMA, the workspace set in -FromWorkspaceID is used to offboard. If it is onboarded via unified or sense agent the, the -FromOrgID is compared to the current value. If they match, the script will run WindowsDefenderATPOffboardingScript_From.cmd.
        
        Once the offboarding completes, the onboarding process is called and functions the same as if a standard onboarding was configured with all of the optional onboarding parameters being applied.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -DownloadUpdates
        
        This example shows how to leverage the DownloadUpdates switch to download all the MDE updates/prerequisites.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -ValidateConfig
        
        This example shows how to use the script to validate the configuration file. The configuration file is a standard PowerShell data file (psd1) and the script will look in its current directory for the file named config.psd1.
        
        It is HIGHLY recommended to run the script with the -ValidateConfig switch to ensure that any configuration changes are valid.
        
    .EXAMPLE
        
        .\Invoke-MDESetup.ps1 -ErrorCode 2056
        
        missing_critical_cu
        reboot_required
        
        This example returns the error string for the given error code.
#>
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWMICmdlet', '', Justification = "Needs to run on Win7 so the CIM cmdlets won't be available")]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', '', Justification = 'The parameters will used once compiled.')]
[CmdletBinding(DefaultParameterSetName = 'config_file')]
param
(
    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_legacy')]
    [switch] $Onboard,

    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [switch] $Offboard,

    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [switch] $SwitchOrg,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [switch] $All,

    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [switch] $Modern,

    [Parameter(ParameterSetName = 'onboard_legacy')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [switch] $Legacy,

    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_legacy')]
    [Parameter(Mandatory = $true, ParameterSetName = 'offboard_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'offboard_legacy')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_legacy')]
    [ValidateScript({ $_ -match '[0-9A-F]{8}[-]?(?:[0-9A-F]{4}[-]?){3}[0-9A-F]{12}' })]
    [guid] $WorkspaceID,

    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_legacy')]
    [ValidateScript({ $_ -match '[0-9A-F]{8}[-]?(?:[0-9A-F]{4}[-]?){3}[0-9A-F]{12}' })]
    [guid] $FromWorkspaceID,

    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_modern')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_legacy')]
    [ValidateScript({ $_ -match '[0-9A-F]{8}[-]?(?:[0-9A-F]{4}[-]?){3}[0-9A-F]{12}' })]
    [guid] $FromOrgID,

    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_legacy')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_legacy')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({
            if ( $_.lenght -ne 88 -and $_ -notmatch '==$' )
            {
                throw 'The WorkspaceKey is valid.'
            }
            return $true
        })]
    [string] $WorkspaceKey,

    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_modern')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'onboard_legacy')]
    [Parameter(Mandatory = $true, ParameterSetName = 'offboard_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'offboard_modern')]
    [Parameter(Mandatory = $true, ParameterSetName = 'offboard_legacy')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_modern')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(Mandatory = $true, ParameterSetName = 'switchorg_legacy')]
    [ValidateSet('Commercial', 'GCC', 'GCC-H', 'DOD')]
    [string] $CloudType,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [ValidateScript({
            if ( -not ($_.IsAbsoluteUri -and $_.Port -ne -1 ))
            {
                throw 'Proxy format should be ''http://<host>:<port>'''
            }
            return $true
        })]
    [uri] $Proxy,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [switch] $PassiveMode,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [switch] $RemoveAgent,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [switch] $MigrateToUnified,

    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [switch] $EnableMMAFallback,

    [Parameter(ParameterSetName = 'config_file')]
    [switch] $ConfigurationFile,

    [Parameter(ParameterSetName = 'config_file')]
    [switch] $ValidateConfig,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [switch] $UpdateDefenderAVAll,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [string[]] $TagList,

    [Parameter(ParameterSetName = 'downloadUpdates')]
    [switch] $DownloadUpdates,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_legacy')]
    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [ValidateScript({ $_.StartsWith('ircstc') })]
    [string] $StorageAccountName,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_legacy')]
    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [ValidateScript({ $_ -match '^\?sv\=\d{4}(-\d{2}){2}(&sr=c|&si=defaultinbound){2}&sig=' })]
    [string] $SASToken,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_legacy')]
    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [switch] $WriteEventLog,

    [Parameter(ParameterSetName = 'onboard_all')]
    [Parameter(ParameterSetName = 'onboard_all_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_modern')]
    [Parameter(ParameterSetName = 'onboard_modern_mmafallback')]
    [Parameter(ParameterSetName = 'onboard_legacy')]
    [Parameter(ParameterSetName = 'offboard_all')]
    [Parameter(ParameterSetName = 'offboard_modern')]
    [Parameter(ParameterSetName = 'offboard_legacy')]
    [Parameter(ParameterSetName = 'switchorg_all')]
    [Parameter(ParameterSetName = 'switchorg_all_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_modern')]
    [Parameter(ParameterSetName = 'switchorg_modern_mmafallback')]
    [Parameter(ParameterSetName = 'switchorg_legacy')]
    [switch] $RefreshFiles,

    [Parameter(Mandatory = $true, ParameterSetName = 'errorCode')]
    [int] $ErrorCode
)

#region data
DATA MDERegionList
{
    @{
        US        = @{
            CnCURLs       = @(
                'https://winatp-gw-cus.microsoft.com/commands/test'
                'https://winatp-gw-eus.microsoft.com/commands/test'
                'https://winatp-gw-cus3.microsoft.com/commands/test'
                'https://winatp-gw-eus3.microsoft.com/commands/test'
            )
            CyberDataURLs = @(
                'https://us.vortex-win.data.microsoft.com/ping'
                'https://us-v20.events.data.microsoft.com/ping'
            )
        }
        EU        = @{
            CnCURLs       = @(
                'https://winatp-gw-weu.microsoft.com/commands/test'
                'https://winatp-gw-neu.microsoft.com/commands/test'
            )
            CyberDataURLs = @(
                'https://eu.vortex-win.data.microsoft.com/ping'
                'https://eu-v20.events.data.microsoft.com/ping'
            )
        }
        UK        = @{
            CnCURLs       = @(
                'https://winatp-gw-uks.microsoft.com/commands/test'
                'https://winatp-gw-ukw.microsoft.com/commands/test'
            )
            CyberDataURLs = @(
                'https://uk.vortex-win.data.microsoft.com/ping'
                'https://uk-v20.events.data.microsoft.com/ping'
            )
        }
        FFL4UsGov = @{
            CnCURLs       = @(
                'https://winatp-gw-usgv.microsoft.com/commands/test'
                'https://winatp-gw-usgt.microsoft.com/commands/test'
            )
            CyberDataURLs = @(
                'https://us4-v20.events.data.microsoft.com/ping'
            )
        }
        FFL4UsMod = @{
            CnCURLs       = @(
                'https://winatp-gw-usmt.microsoft.com/commands/test'
                'https://winatp-gw-usmv.microsoft.com/commands/test'
            )
            CyberDataURLs = @(
                'https://us4-v20.events.data.microsoft.com/ping'
            )
        }
        ASM       = @{
            CnCURLs = @(
                'https://winatp-gw-asmc.microsoft.com/asm/test'
                'https://winatp-gw-asmw.microsoft.com/asm/test'
            )
        }
        ALL       = @{
            Events   = @(
                'https://events.data.microsoft.com/ping'
            )
            Settings = @(
                'https://settings-win.data.microsoft.com/qos'
            )
        }
    }
}


DATA UpdateMetadata
{
    @{
        # AntiMalware Platform Update
        'UpdatePlatform-x64.exe'       = 'https://go.microsoft.com/fwlink/?linkid=870379&arch=x64'
        'UpdatePlatform-x86.exe'       = 'https://go.microsoft.com/fwlink/?linkid=870379&arch=x86'

        # AntiMalware Definition Update
        'mpamfe-x64.exe'               = 'https://go.microsoft.com/fwlink/?LinkID=121721&arch=x64'
        'mpamfe-x86.exe'               = 'https://go.microsoft.com/fwlink/?LinkID=121721&arch=x86'

        'MMASetup-x64.exe'             = 'https://go.microsoft.com/fwlink/?LinkId=828603'
        'MMASetup-x86.exe'             = 'https://go.microsoft.com/fwlink/?LinkId=828604'

        'Windows6.1-KB3080149-x64.msu' = 'https://download.microsoft.com/download/4/E/8/4E864B31-7756-4639-8716-0379F6435016/Windows6.1-KB3080149-x64.msu'
        'Windows6.1-KB3080149-x86.msu' = 'https://download.microsoft.com/download/C/8/0/C8036E07-4382-46BD-BFFB-46A6D397222A/Windows6.1-KB3080149-x86.msu'

        'Windows8.1-KB3080149-x64.msu' = 'https://download.microsoft.com/download/A/3/E/A3E82C15-7762-4104-B969-6A486C49DB8D/Windows8.1-KB3080149-x64.msu'
        'Windows8.1-KB3080149-x86.msu' = 'https://download.microsoft.com/download/C/B/F/CBF18876-FA6C-4B85-8D1E-2C41CD5F828F/Windows8.1-KB3080149-x86.msu'

        # These updates are no longer available, so if the endpoint requires a tls update for .Net, apply the latest 3.5 updates, or update to 4.5+
        #'windows6.1-kb3154518-x64.msu' = 'http://download.microsoft.com/download/6/8/0/680ee424-358c-4fdf-a0de-b45dee07b711/windows6.1-kb3154518-x64.msu'
        #'windows6.1-kb3154518-x86.msu' = 'http://download.microsoft.com/download/6/8/0/680ee424-358c-4fdf-a0de-b45dee07b711/windows6.1-kb3154518-x86.msu'

        'Windows8.1-KB2999226-x64.msu' = 'https://download.microsoft.com/download/D/1/3/D13E3150-3BB2-4B22-9D8A-47EE2D609FFF/Windows8.1-KB2999226-x64.msu'

        # https://support.microsoft.com/en-us/topic/microsoft-defender-for-endpoint-update-for-edr-sensor-f8f69773-f17f-420f-91f4-a8e5167284ac
        # this update gets released periodically, and with the same KB number (5005292) and Microsoft IR manages the link.
        'updatesenseclient.exe'        = 'https://go.microsoft.com/fwlink/?linkid=2221543'

        'md4ws.msi'                    = 'https://go.microsoft.com/fwlink/?linkid=2168294'
    }
}


DATA Windows7Manifest
{
    @{
        UpdateList = @(
            @{
                Name         = 'KB4074598'
                Required     = $true
                FileName     = 'manual_cu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'KB3080149'
                Required     = $true
                FileName     = 'Windows6.1-KB3080149-{0}.msu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'KB3154518'
                Required     = $true
                FileName     = 'windows6.1-kb3154518-{0}.msu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            }
        )
        SCEP       = @{
            Remove       = $false
            InstallState = ''
            ExitCode     = 0
        }
        MDE        = @{
            State        = ''
            Connectivity = ''
            DeviceId     = ''
            OrgId        = ''
            Action       = @{
                Type     = ''
                FilePath = ''
                ExitCode = 0
            }
            Agent        = @{
                Type            = 'Legacy'
                RequiresInstall = $true
                RequiresUpdate  = $false
                AllowFallback   = $false
                AllowMigrate    = $false
                FileName        = ''
                FilePath        = ''
                InstallState    = ''
                ExitCode        = 0
            }
        }
    }
}


DATA Windows81Manifest
{
    @{
        UpdateList = @(
            # @{
            #     Name         = 'KB2919355'
            #     FileName     = ''
            #     FilePath     = ''
            #     InstallState = ''
            # },
            @{
                Name         = 'KB3080149'
                Required     = $true
                FileName     = 'Windows8.1-KB3080149-{0}.msu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            }
        )
        SCEP       = @{
            Remove       = $false
            InstallState = ''
            ExitCode     = 0
        }
        MDE        = @{
            State        = ''
            Connectivity = ''
            DeviceId     = ''
            OrgId        = ''
            Action       = @{
                Type     = ''
                FilePath = ''
                ExitCode = 0
            }
            Agent        = @{
                Type            = 'Legacy'
                RequiresInstall = $true
                RequiresUpdate  = $false
                AllowFallback   = $false
                AllowMigrate    = $false
                FileName        = ''
                FilePath        = ''
                InstallState    = ''
                ExitCode        = 0
            }
        }
    }
}


DATA WindowsModernManifest
{
    @{
        UpdateList = @(
            @{
                Name         = 'UpdatePlatform'
                Required     = $false
                FileName     = 'UpdatePlatform-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'MpamFe'
                Required     = $false
                FileName     = 'MpamFe-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            }
        )
        SCEP       = @{
            Remove       = $false
            InstallState = ''
            ExitCode     = 0
        }
        MDE        = @{
            State        = ''
            Connectivity = ''
            DeviceId     = ''
            OrgId        = ''
            Action       = @{
                Type     = ''
                FilePath = ''
                ExitCode = 0
            }
            Agent        = @{
                Type            = 'Modern'
                RequiresInstall = $false
                RequiresUpdate  = $false
                AllowFallback   = $false
                AllowMigrate    = $false
                FileName        = ''
                FilePath        = ''
                InstallState    = ''
                ExitCode        = 0
            }
        }
    }
}


DATA WindowsServer2k12R2Manifest
{
    @{
        UpdateList = @(
            @{
                Name         = 'UpdatePlatform'
                Required     = $false
                FileName     = 'UpdatePlatform-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'MpamFe'
                Required     = $false
                FileName     = 'MpamFe-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'KB2999226'
                Required     = $true
                FileName     = 'windows8.1-KB2999226-{0}.msu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
                # Update for Universal C Runtime in Windows
                # Required for Unified oboarding
            },
            @{
                Name         = 'KB3080149'
                Required     = $true
                FileName     = 'Windows8.1-KB3080149-{0}.msu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
                # Update for customer experience and diagnostic telemetry
                # Required for Legacy and Unified oboarding
            },
            @{
                Name         = 'KB5006714'
                Required     = $true
                FileName     = 'manual_cu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
                # TO DO This is a known issue in the Unified agent, but not a hard blocker is it?
                # Recommended for Unified oboarding
                # Network Events may not populate in the timeline.
                # Oct 2021 CU
            }
        )
        SCEP       = @{
            Remove       = $true
            InstallState = ''
            ExitCode     = 0
        }
        MDE        = @{
            State        = ''
            Connectivity = ''
            DeviceId     = ''
            OrgId        = ''
            Action       = @{
                Type     = ''
                FilePath = ''
                ExitCode = 0
            }
            Agent        = @{
                Type            = 'Modern'
                RequiresInstall = $true
                RequiresUpdate  = $false
                AllowFallback   = $true
                AllowMigrate    = $false
                FileName        = ''
                FilePath        = ''
                InstallState    = ''
                ExitCode        = 0
                UpdateName      = ''
                UpdateFilePath  = ''
                UpdateExitCode  = 0
            }
        }
    }
}


DATA WindowsServer2k16Manifest
{
    @{
        UpdateList = @(
            @{
                Name         = 'UpdatePlatform'
                Required     = $true
                FileName     = 'UpdatePlatform-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'MpamFe'
                Required     = $true
                FileName     = 'MpamFe-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'KB5005573'
                Required     = $true
                FileName     = 'manual_cu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            }
        )
        SCEP       = @{
            Remove       = $false
            InstallState = ''
            ExitCode     = 0
        }
        MDE        = @{
            State        = ''
            Connectivity = ''
            DeviceId     = ''
            OrgId        = ''
            Action       = @{
                Type     = ''
                FilePath = ''
                ExitCode = 0
            }
            Agent        = @{
                Type            = 'Modern'
                RequiresInstall = $true
                RequiresUpdate  = $false
                AllowFallback   = $true
                AllowMigrate    = $false
                FileName        = ''
                FilePath        = ''
                InstallState    = ''
                ExitCode        = 0
                UpdateName      = ''
                UpdateFilePath  = ''
                UpdateExitCode  = 0
            }
        }
    }
}


DATA WindowsServer2k8R2Manifest
{
    @{
        UpdateList = @(
            @{
                Name         = 'KB4074598'
                Required     = $true
                FileName     = 'manual_cu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'KB3080149'
                Required     = $true
                FileName     = 'Windows6.1-KB3080149-{0}.msu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'KB3154518'
                Required     = $true
                FileName     = 'windows6.1-kb3154518-{0}.msu'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            }
        )
        SCEP       = @{
            Remove       = $false
            InstallState = ''
            ExitCode     = 0
        }
        MDE        = @{
            State        = ''
            Connectivity = ''
            DeviceId     = ''
            OrgId        = ''
            Action       = @{
                Type     = ''
                FilePath = ''
                ExitCode = 0
            }
            Agent        = @{
                Type            = 'Legacy'
                RequiresInstall = $true
                RequiresUpdate  = $false
                AllowFallback   = $false
                AllowMigrate    = $false
                FileName        = ''
                FilePath        = ''
                InstallState    = ''
                ExitCode        = 0
            }
        }
    }
}


DATA WindowsServerModernManifest
{
    @{
        UpdateList = @(
            @{
                Name         = 'UpdatePlatform'
                Required     = $false
                FileName     = 'UpdatePlatform-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            },
            @{
                Name         = 'MpamFe'
                Required     = $false
                FileName     = 'MpamFe-{0}.exe'
                FilePath     = ''
                InstallState = ''
                ExitCode     = 0
            }
        )
        SCEP       = @{
            Remove       = $false
            InstallState = ''
            ExitCode     = 0
        }
        MDE        = @{
            State        = ''
            Connectivity = ''
            DeviceId     = ''
            OrgId        = ''
            Action       = @{
                Type     = ''
                FilePath = ''
                ExitCode = 0
            }
            Agent        = @{
                Type            = 'Modern'
                RequiresInstall = $false
                RequiresUpdate  = $false
                AllowFallback   = $false
                AllowMigrate    = $false
                FileName        = ''
                FilePath        = ''
                InstallState    = ''
                ExitCode        = 0
            }
        }
    }
}


#endregion data

#region functions
<#
    .Synopsis
        Converts a hashtable into a jsonl doc for kusto ingestion
    .Parameter Manifest
        The OS manifest that will be converted to jsonl
#>
function ConvertTo-JsonL
{
    [CmdletBinding()]
    [OutputType([String])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Hashtable] $InputObject
    )

    begin
    {
        $return = '{{{0}}}'
    }
    process
    {
        $innerObject = @()
        foreach ($item in $InputObject.GetEnumerator())
        {
            $innerValue = $null

            if ($null -eq $item.Value)
            {
                # nulls shouldn't get here, but they break the kusto queries if they do.
                $innerValue = '""'
            }
            elseif ($item.Value.GetType().Name -eq 'Hashtable')
            {
                $innerValue = $item.Value | ConvertTo-JsonL
            }
            elseif ($item.Value.GetType().BaseType.Name -eq 'Array')
            {
                $innerArrayItemList = $item.Value | ForEach-Object -Process { ConvertTo-JsonL -InputObject $_ }
                $innerValue = '[{0}]' -f ($innerArrayItemList -join ',')
            }
            elseif ($item.Value.GetType().Name -match 'Boolean|Int32')
            {
                $innerValue = '{0}' -f $item.Value.ToString().ToLower()
            }
            else
            {
                # https://docs.microsoft.com/en-us/sql/relational-databases/json/how-for-json-escapes-special-characters-and-control-characters-sql-server?view=sql-server-ver15#escaping-of-special-characters
                $escapeCharList = @{
                    '"' = '\"' # Quotation mark (")
                    '\' = '\\' # Backslash (\)
                    '/' = '\/' # Slash (/)
                }

                $itemValue = $item.Value.ToString().Replace('"', $escapeCharList['"']).Replace('\', $escapeCharList['\']).Replace('/', $escapeCharList['/'])

                $innerValue = '"{0}"' -f $itemValue
            }

            $innerObject += ('"{0}":{1}' -f $item.Key, $innerValue)
        }
    }
    end
    {
        ($return -f ($innerObject -join ','))
    }
}


<#
    .Synopsis
        Check Windows Defender installation to determine if the endpoint can be onbaorded to MDE with the unified agent
    .Notes
        This Should only run on 2016
    .Link
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/microsoft-defender-antivirus-compatibility?view=o365-worldwide#microsoft-defender-antivirus-and-non-microsoft-antivirusantimalware-solutions
#>
function Get-DefenderAV
{
    [CmdletBinding()]
    [OutputType([PSObject])]
    param ( )

    $defender = @{
        InstallState = '' # installed, available, unavailable # if not installed on 2016, we can't onboard because the install will require a reboot and the script won't survive the reboot
        Status       = '' # stopped, running                  # if stopped, there is most likely third party AV stepping Defender, but we can try to start it
        Mode         = '' # Normal, Passive Mode              # https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/edr-in-block-mode?view=o365-worldwide#how-do-i-confirm-microsoft-defender-antivirus-is-in-active-or-passive-mode
        Platform     = '' # Platform version number           # we might do a little date math on the build number to determine if it is supported or not N-2 max
    }

    $defender.Platform = Get-DefenderAVPlatform
    $windefend = Get-Service -Name 'Windefend' -ErrorAction SilentlyContinue

    if ($windefend.Status -eq 'Running')
    {
        Write-LogFile -Message 'Windows Defender is running.'

        $defender.InstallState = 'installed'
        $defender.Mode = ''
        $defender.Status = $windefend.Status
    }
    elseif ($windefend.Status -eq 'Stopped')
    {
        Write-LogFile -Message 'Windows Defender is Stopped.' -TypeName Warning

        $winDefend = Start-MDEService -Name 'WinDefend' -Verify

        if ($winDefend.Status -ne 'Running')
        {
            Write-LogFile -Message ('Windows Defender failed to start. Status {0}' -f $winDefend.Status) -TypeName Error

            # If the platform is older than Aug 2020, then we have to force enable it, by setting Disable to false. #justTrustMeOnThisOne
            $defenderPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender'
            $disableName = 'DisableAntiSpyware' # Ignored after AUG 2020 update 4.18.2008.9
            $disableValue = 0
            $disableAntiSpyware = Get-ItemProperty -Path $defenderPath -Name $disableName -ErrorAction SilentlyContinue

            if ($disableAntiSpyware.DisableAntiSpyware -ne $disableValue)
            {
                Write-LogFile -Message 'Setting DisableAntiSpyware registry key.'
                if (-not (Test-Path -Path $defenderPath))
                {
                    New-Item -Path $defenderPath | Out-Null
                }

                New-ItemProperty -Path $defenderPath -Name $disableName -Value $disableValue -PropertyType 'DWord' -Force | Out-Null

                # Defender is now force disabled so try to start the service
                $winDefend = Start-MDEService -Name 'WinDefend'

                if ($winDefend.Status -ne 'Running')
                {
                    # We can't onboard, because something is still stepping on Defender
                    Write-LogFile -Message ('Windows Defender failed to start. Status {0}. Check third party security software that might be blocking Defender.' -f $winDefend.Status) -TypeName Error
                }
                else
                {
                    Write-LogFile -Message 'Windows Defender is running.'
                }
            }
            else
            {
                # We should have been able to start, so not sure how we get here
            }
        }
        else
        {
            Write-LogFile -Message 'Windows Defender is running.'
        }

        $defender.InstallState = 'installed'
        $defender.Mode = ''
        $defender.Status = $windefend.Status
    }
    elseif ($null -eq $windefend)
    {
        Write-LogFile -Message 'Windows Defender is not installed.' -TypeName Error

        try
        {
            $defender.InstallState = (Get-WindowsFeature -Name 'Windows-Defender').InstallState
        }
        catch
        {
            $defender.InstallState = $null
        }

        if ($null -eq $defender.InstallState)
        {
            $defender.InstallState = 'unavailable'
        }
    }

    $defender
}


<#
    .Synopsis
        Gets the most current platform version number from the file system. The file system is checked
        because the cmdlets that provide this information are not available if the platform is older than
        Aug 2020.
#>
function Get-DefenderAVPlatform
{
    [CmdletBinding()]
    [OutputType([version])]
    param ( )

    try
    {
        $AMProductVersion = (Get-MpComputerStatus -ErrorAction 'Stop').AMProductVersion
    }
    catch
    {
        $platformPath = ('{0}\Microsoft\Windows Defender\Platform' -f $env:ProgramData)
        [string[]] $version = (Get-ChildItem -Path $platformPath -ErrorAction SilentlyContinue |
                Sort-Object -Property 'Name' -Descending |
                    Select-Object -ExpandProperty 'Name' -First 1)

        if ($null -eq $version)
        {
            $AMProductVersion = '0.0.0.0'
        }
        else
        {
            $AMProductVersion = ($version -split '-')[0]
        }
    }
    finally
    {
        [version] $AMProductVersion
    }
}


<#
    .Synopsis
        Gets the roles specified in the $roleMap hashtable to determine DeviceTagging.
    .Notes
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/machine-tags?view=o365-worldwide
        https://docs.microsoft.com/en-us/Exchange/plan-and-deploy/deployment-ref/services-overview?view=exchserver-2016#exchange-services-on-edge-transport-servers
        https://docs.microsoft.com/en-us/exchange/overview-of-exchange-2013-services-exchange-2013-help#exchange-services-on-exchange-2013-edge-transport-servers

#>
function Get-DeviceTag
{
    [CmdletBinding()]
    [OutputType([string])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateSet('Modern', 'Legacy')]
        [string] $AgentType,

        [Parameter()]
        [AllowNull()]
        [string[]] $TagList
    )

    $result = New-Object -TypeName 'System.Collections.ArrayList'

    $roleMap = @(
        @{
            TagName     = 'DomainController'
            ServiceName = 'NTDS'
        }
        @{
            TagName     = 'ADFS'
            ServiceName = 'adfssrv'
        }
        @{
            TagName     = 'Exchange'
            ServiceName = 'MSExchangeDiagnostics'
        }
    )

    foreach ($role in $roleMap)
    {
        $rolePresent = Get-Service -Name $role.ServiceName -ErrorAction 'SilentlyContinue'

        if ($null -ne $rolePresent)
        {
            if (
                $role.ServiceName -eq 'NTDS' -and
                $rolePresent.Status -ne 'Running' -and
                $rolePresent.StartType -ne 'Automatic'
            )
            {
                continue
            }

            $null = $result.Add($role.TagName)
        }
    }

    if ($AgentType -eq 'Legacy')
    {
        $null = $result.Add($AgentType)
    }

    if ($null -ne $TagList)
    {
        $null = $result.AddRange($TagList)
    }

    return ($result -join ',')
}


<#
    .SYNOPSIS
        First look to see if the required file is in the local invocation folder (manual script run scenario).
        If file is not found in the local invocation directory copy them from the remote share ($env:mySourcePath)
        to $env:myDestPath. $env:myDestPath and $env:mySourcePath are configured via GPO. This allows for all contents
        to be copied via SCCM to a single location or to allow GPO deployment of just the script and have the script
        manage the file download from sysvol.
    .PARAMETER FileName
        The name of the file to look for.
    .PARAMETER Refresh
        A switch that will redownload the file if it is different on the server.
#>
function Get-OnboardingFile
{
    [CmdletBinding()]
    [OutputType([string])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $FileName,

        [Parameter()]
        [switch] $Refresh
    )

    $fileExists = $false
    # check to see if there are myDestPath and mySourcePath environment variables from GPO
    $myDestPath = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment' -Name 'myDestPath' -ErrorAction 'SilentlyContinue').MyDestPath
    $mySourcePath = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment' -Name 'mySourcePath' -ErrorAction 'SilentlyContinue').MySourcePath

    # Get the setup type from the call stack
    #$null = (Get-PSCallStack)[0].Location -match '\w+-(?<target>\w+)'
    $setupType = 'MDESetup' #$matches.target

    # $PSCmdlet.MyInvocation.ScriptName is available across all versions of PS
    $invocationPath = Split-Path -Path $PSCmdlet.MyInvocation.ScriptName
    $localInstallerPath = Join-Path $invocationPath -ChildPath $FileName

    if (Test-Path -Path $localInstallerPath) # manual script invocation, check for files locally
    {
        Write-LogFile -Message ('{0} found in local invocation directory. {1}' -f $FileName, $localInstallerPath)
        $mdeFilePath = $localInstallerPath
        $fileExists = $true
    }
    # a null check is required first, because Test-Path will throw an error if $env:myDestPath is null even with
    # the error pref set to SilentlyContinue. By anding the null check first, .Net optimization will return false
    # before running the Test-Path
    elseif ($null -ne $myDestPath) # myDestPath and mySource set via GPO
    {
        $myDestPath = Join-Path -Path $myDestPath -ChildPath $setupType
        $mySourcePath = Join-Path -Path $mySourcePath -ChildPath $setupType

        if (Test-Path -Path $myDestPath)
        {
            $localMyDestinationPath = Join-Path -Path $myDestPath -ChildPath $FileName

            if (Test-Path -Path $localMyDestinationPath)
            {
                Write-LogFile -Message ('Setup file found in myDestPath {0}.' -f $localMyDestinationPath)
                $mdeFilePath = $localMyDestinationPath
                $fileExists = $true
            }
            elseIf (($null -ne $mySourcePath) -and (Test-Path -Path $mySourcePath))
            {
                $sourcePath = Join-Path -Path $mySourcePath -ChildPath $FileName

                try
                {
                    $copyResult = Copy-Item -Path $sourcePath -Destination $myDestPath -ErrorAction Stop -PassThru
                    $mdeFilePath = $copyResult.FullName
                }
                catch
                {
                    Write-LogFile -Message ('Setup file not found {0}. Cannot continue.' -f $FileName ) -TypeName Error
                    $mdeFilePath = $null
                }
            }
            else
            {
                Write-LogFile -Message 'Ensure $env:mySourcePath contains the needed files and rerun.' -TypeName Error
                $mdeFilePath = $null
            }
        }
    }
    else
    {
        Write-LogFile -Message ('{0} not found in the local invocation directory and myDesPath is null.' -f $FileName) -TypeName Error
        $mdeFilePath = $null
    }

    if ($fileExists -and $Refresh)
    {
        $remotePath = Join-Path -Path $mySourcePath -ChildPath $FileName
        $localPath = Join-Path -Path $myDestPath -ChildPath $FileName

        $remoteHash = Get-OnboardingFileHash -FilePath $remotePath
        $localHash = Get-OnboardingFileHash -FilePath $localPath

        if ($remoteHash -ne $localHash)
        {
            $copyResult = Copy-Item -Path $remotePath -Destination $myDestPath -ErrorAction Stop -PassThru
            $mdeFilePath = $copyResult.FullName
        }
    }

    # TODO This doesn't work on Win7, so we need to make a decision on using this
    # We need to update documentation to unblock all setup files at setup time.
    # Unblock-File -Path $destinationPath

    $mdeFilePath
}


<#
    .SYNOPSIS
        A helper function that wraps certutil to return the hash of a file.
        If certutil is not found on the end point, the current timestamp is returned. If files are being hashed, it means
        that there is a scenario that requires local files to be updated. Instead of failing and not updating files, they
        will always be different. This may have some overhead, but it will resolve the stale file problem.
    .PARAMETER FilePath
        The path to the file to be hashed.
    .NOTES
        File hashing is not the default behavior of the setup solution, and this is only a utility that is used in edge cases.
#>
function Get-OnboardingFileHash
{
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingInvokeExpression', '', Justification = 'Inputs are restricted.')]
    [CmdletBinding()]
    [OutputType([string])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo] $FilePath
    )

    try
    {
        $certUtil = Get-Command -Name Certutil -ErrorAction Stop
        $result = Invoke-Expression -Command ('{0} -hashfile {1}  SHA256' -f $certUtil.Source, $FilePath.FullName)
        ($result | Select-String '[A-Fa-f0-9]{64}').ToString()
    }
    catch
    {
        (Get-Date).ToString('yymmddhhmmssfff')
    }
}


<#
    .SYNOPSIS
        Get MDE Onboarding status of the endpoint to inclued the OrgId of the tenant that the endpoint is onboarded to.
    .DESCRIPTION
        This function looks at the current system state as well as how the manifest says the endpoint should be configured
        The endpoint is checked for both the Sense Agent and MMA installation. Once the list of agents are known, they
        are compared against the manifest and then the agent install state is updated to reflect the need to do additional
        work.
    .PARAMETER AgentType
        The agent type defined in the OS manifest.
    .PARAMETER WorkspaceID
        The Workspace ID from the MDE portal to onboard down level endpoints.
#>
function Get-MDEStatus
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter()]
        [guid] $WorkspaceID
    )

    $mdeRegPath = 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status'

    $mdeStatus = @{
        State = ''
        OrgID = (Get-ItemProperty -Path $mdeRegPath -Name 'OrgId' -ErrorAction 'SilentlyContinue').OrgId
    }

    $senseService = Get-SenseInstallState

    if ($senseService.InstallState -eq 'not_installed')
    {
        $mdeStatus.State = 'not_onboarded'
    }
    else
    {
        $onboardingState = (Get-ItemProperty -Path $mdeRegPath -Name 'OnboardingState' -ErrorAction 'SilentlyContinue').OnboardingState

        if ($senseService.State -eq 'Running' -and $onboardingState -eq 1)
        {
            $mdeStatus.State = 'onboarded'
        }
        else
        {
            $mdeStatus.State = 'not_onboarded'
        }
    }

    if (($null -ne $WorkspaceID) -and ($mdeStatus.State -eq 'not_onboarded'))
    {
        $mma = Get-MMAInstallState

        if ($mma.InstallState -ne 'not_installed')
        {
            $mgmtSvcCfg = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg' -ErrorAction 'SilentlyContinue'

            if ($null -ne $mgmtSvcCfg.GetCloudWorkspace($WorkspaceID))
            {
                $mdeStatus.State = 'mma_onboarded'
            }
        }
    }

    $mdeStatus
}


<#
    .Synopsis
        Checks the installed version of the MMA against the latest version.
    .Parameter MinVersion
        The currently available version of the MMA.
        This is primarily to aid testing, but can be used for normal calls if this data is
        stored or linked externally in the future.
#>
function Get-MMAInstallState
{
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWMICmdlet', '', Justification = 'Needs to run on Win7 and the CIM cmdlets wont be available')]
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter()]
        [version] $MinVersion = '10.20.18067.0'
    )

    $service = Get-WmiObject -Query 'Select Name,State from Win32_Service where Name = "HealthService"'

    $return = @{
        InstallState = ''
        State        = ''
    }

    if ($null -eq $service)
    {
        $return.InstallState = 'not_installed'
        $return.State = ''
    }
    else
    {
        $agentPath = Join-Path -Path $env:ProgramFiles -ChildPath 'Microsoft Monitoring Agent\Agent\HealthService.exe'
        [version] $installedVersion = (Get-Item -Path $agentPath).VersionInfo.ProductVersion

        if ($installedVersion -lt $MinVersion)
        {
            $return.InstallState = 'not_current'
        }
        else
        {
            $return.InstallState = 'current'
        }

        $return.State = $service.State
    }

    return $return
}


<#
    .Synopsis
        Searches for an MSI using the application Displayname.
    .Parameter DisplayName
        The disply name to search for.
#>
function Get-MSI
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $DisplayName
    )

    $searchPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'

    [Microsoft.Win32.RegistryKey[]] $msiList = Get-ChildItem -Path $searchPath
    $msi = $msiList | Where-Object -FilterScript { $_.GetValue('DisplayName') -eq $DisplayName }

    switch (($msi | Measure-Object).Count)
    {
        0
        {
            return $null
        }
        1
        {
            return @{
                DisplayName = $msi.GetValue('DisplayName')
                ProductCode = $msi.GetValue('UninstallString') -Replace 'msiexec\.exe\s\/(i|x)(\s)?', ''
            }
        }
        { $_ -gt 1 }
        {
            throw ('Multiple installers found for {0}' -f $DisplayName)
        }
    }
}


<#
    .Synopsis
        Gets the details of the currently running OS from WMI and then creates a hashtable
        that contains the important attributes as well as any currently running MDE services.
    .Notes
        The output of this function drives the rest of the script.
#>
function Get-OS
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWMICmdlet', '', Justification = "Needs to run on Win7 so the CIM cmdlets won't be available")]
    param ( )

    $legacyServerBuildList = @('10074', '10514', '10586', '14300', '14393', '16299', '17134')

    $osWmi = Get-WmiObject -Class 'Win32_OperatingSystem' -Namespace 'root\cimv2'

    # https://docs.microsoft.com/en-us/dotnet/api/microsoft.powershell.commands.producttype?view=powershellsdk-1.1.0
    $productType = @{
        0 = 'Unknown'
        1 = 'WorkStation'
        2 = 'DomainController'
        3 = 'Server'
    }

    if ($env:PROCESSOR_ARCHITECTURE -eq 'AMD64')
    {
        $architecture = 'x64'
    }
    else
    {
        $architecture = 'x86'
    }

    $instance = @{
        Error                   = $false
        IsSupported             = $true
        RunGuid                 = [Guid]::NewGuid().Guid.ToLower()
        RunDate                 = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        ManifestName            = ''
        OSName                  = '{0} ({1})' -f $osWmi.Caption, $osWmi.Version
        Architecture            = $architecture
        DeviceNetBIOSName       = [Environment]::MachineName
        DeviceTag               = ''
        DomainName              = [Environment]::UserDomainName
        DomainRole              = $productType[[int]$osWmi.ProductType]
        DefenderAV              = @{}
        DefenderAVForcePassive  = $false
        DefenderAVUpdateEnabled = $false
        IsWindowsUpdateDisabled = $false
        ReturnCode              = ''
    }

    switch ($osWmi.ProductType)
    {
        { $_ -eq 1 }
        {
            if ($osWmi.Version -like '6.1.*')
            {
                $instance.ManifestName = 'Windows7'
            }
            elseif ($osWmi.Version -like '6.3.*')
            {
                $instance.ManifestName = 'Windows81'
            }
            elseif ($osWmi.Version -like '10.*')
            {
                $instance.ManifestName = 'WindowsModern'
            }
            else
            {
                $instance.IsSupported = $false
            }

            break
        }
        { $_ -ge 2 }
        {
            if ($osWmi.Version -like '6.1.*')
            {
                $instance.ManifestName = 'WindowsServer2k8R2'
            }
            elseif ($osWmi.Version -like '6.3.*')
            {
                $instance.ManifestName = 'WindowsServer2k12R2'
                $instance.DefenderAVForcePassive = $true
            }
            elseif ($legacyServerBuildList -contains $osWmi.BuildNumber)
            {
                $instance.ManifestName = 'WindowsServer2k16'
                $instance.DefenderAVForcePassive = $true
            }
            elseif ($osWmi.BuildNumber -ge '17677')
            {
                $instance.ManifestName = 'WindowsServerModern'
                # On Windows Server 2019, Windows Server version 1803 or newer, Windows Server 2016, or Windows Server 2012 R2
                # Microsoft Defender Antivirus does not enter passive mode automatically when you install a non-Microsoft antivirus product.
                $instance.DefenderAVForcePassive = $true
            }
            else
            {
                $instance.IsSupported = $false
            }
        }
    }

    $instance
}


<#
    .Synopsis
        Retrieves the current proxy configuration from the registry in the WinHttp and TelemetryProxyServer keys.
    .Description
        Retrieves the current proxy configuration from the following registry keys:
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections\WinHttpSettings'
        'HKLM:\Software\Policies\Microsoft\Windows\DataCollection\TelemetryProxyServer'
        'HKLM:\Software\Policies\Microsoft\Windows\DataCollection\DisableEnterpriseAuthProxy'
    .Link
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/configure-proxy-internet?view=o365-worldwide
#>
function Get-ProxySettings
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param ()

    Write-LogFile -Message 'Checking if any proxy settings currently exist.'

    $proxySettings = @{
        WinHttpSettings            = @{
            State = $false
            Path  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections'
            Value = ''
        }

        TelemetryProxyServer       = @{
            State = $false
            Path  = 'HKLM:\Software\Policies\Microsoft\Windows\DataCollection'
            Value = ''
        }

        DisableEnterpriseAuthProxy = @{
            State = $false
            Path  = 'HKLM:\Software\Policies\Microsoft\Windows\DataCollection'
            Value = ''
        }

        ProxyServer                = @{ # this is the MDAV proxy key
            State = $false
            Path  = 'HKLM:\Software\Policies\Microsoft\Windows Defender'
            Value = ''
        }
    }

    $proxyCheck = Get-ItemProperty -Path $ProxySettings.WinHttpSettings.Path -Name 'WinHttpSettings' -ErrorAction Stop

    $proxySettingString = [System.Text.Encoding]::Ascii.GetString($proxyCheck.WinHttpSettings) -replace '[^\d|.|:]'

    if ([string]::IsNullOrWhiteSpace($proxySettingString))
    {
        Write-LogFile -Message 'No WinHTTP proxy settings currently Configured.'

        foreach ($proxySetting in ($proxySettings.GetEnumerator() | Where-Object { $_.key -ne 'WinHttpSettings' }))
        {
            try
            {
                $currentSetting = Get-ItemProperty -Path $proxySetting.Value['Path'] -Name $proxySetting.Name -ErrorAction Stop

                if ($null -ne $currentSetting.($proxySetting.Name))
                {
                    Write-LogFile -Message ('Proxy settings found in registry path {0} property: {1}' -f $proxySetting.Value['Path'], $proxySetting.Name)
                    $proxySetting.Value['State'] = $true
                    $proxySetting.Value['Value'] = $currentSetting.($proxySetting.Name)
                }
            }
            catch
            {
                Write-LogFile -Message ('Proxy settings not found in registry path {0} property: {1}' -f $proxySetting.Value['Path'], $proxySetting.Name)
            }
        }

        return $proxySettings
    }
    else
    {
        Write-LogFile -Message ('Proxy settings found in registry path {0} property: {1}' -f $proxyRegistryPath.Path, $proxyRegistryPath.Name)
        $proxySettings.WinHttpSettings.State = $true
        $proxySettings.WinHttpSettings.Value = $proxySettingString
        return $proxySettings
    }
}


<#
    .Synopsis
        Processes the manifest and takes the return code from each step and creates a bitmask.
    .Parameter Manifest
        OS manifest object
    .Parameter ErrorCode
        Returns the error string(s) for the given error code
    .Example
        Get-ReturnCode -ErrorCode 17

        Returns the following error strings

            wuau_disabled
            KB2919355_failed
#>
function Get-ReturnCode
{
    [CmdletBinding()]
    [OutputType([int], ParameterSetName = ('code', 'string2code'))]
    [OutputType([string], ParameterSetName = 'code2string')]
    param
    (
        [Parameter(ParameterSetName = 'code', Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(ParameterSetName = 'code', Mandatory = $true)]
        [ValidateSet('onboard', 'offboard')]
        [string] $Action,

        [Parameter(ParameterSetName = 'code')]
        [switch] $RemoveAgent,

        [Parameter(ParameterSetName = 'code2string', Mandatory = $true)]
        [int] $ErrorCode,

        [Parameter(ParameterSetName = 'string2code', Mandatory = $true)]
        [string] $ErrorString
    )

    # https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_arithmetic_operators?view=powershell-7.2#bitwise-operators
    # Beginning in PowerShell 2.0, all bitwise operators work with 64-bit integers.

    $errorStringTable = @{
        'success'                      = 0x00000000 # 0  (0
        'wuau_disabled'                = 0x00000001 # 1  (1
        'missing_param_in_config'      = 0x00000002 # 2  (2
        'installer_invalid_signature'  = 0x00000004 # 3  (4
        'reboot_required'              = 0x00000008 # 4  (8
        'KB2919355_failed'             = 0x00000010 # 5  (16
        'KB2999226_failed'             = 0x00000020 # 6  (32
        # = 0x00000040 # 7  (64
        'KB4074598_failed'             = 0x00000080 # 8  (128
        'KB3080149_failed'             = 0x00000100 # 9  (256
        'KB3154518_failed'             = 0x00000200 # 10 (512
        # = 0x00000400 # 11 (1024
        'missing_critical_cu'          = 0x00000800 # 12 (2048
        'windows_defender_not_enabled' = 0x00001000 # 13 (4096
        'windows_defender_not_started' = 0x00002000 # 14 (8192
        # = 0x00004000 # 15 (16384
        'scep_uninstall_failed'        = 0x00008000 # 16 (32768
        'legacy_install_failed'        = 0x00010000 # 17 (65536
        'legacy_onboard_failed'        = 0x00020000 # 18 (131072
        'legacy_offboard_failed'       = 0x00040000 # 19 (262144
        'legacy_uninstall_failed'      = 0x00080000 # 20 (524288
        'modern_install_failed'        = 0x00100000 # 21 (1048576
        'modern_onboard_failed'        = 0x00200000 # 22 (2097152
        'modern_offboard_failed'       = 0x00400000 # 23 (4194304
        'modern_uninstall_failed'      = 0x00800000 # 24 (8388608
        'mySourcePath_missing'         = 0x01000000 # 25 (16777216
        # = 0x02000000 # 26 (33554432
        # = 0x04000000 # 27 (67108864
        # = 0x08000000 # 28 (134217728
        'workspace_key_invalid'        = 0x10000000 # 29 (268435456
        'manifest_error'               = 0x20000000 # 30 (536870912
        'Unknown_Failure'              = 0x40000000 # 31 (1073741824
    }

    if ($PSCmdlet.ParameterSetName -eq 'string2code')
    {
        $errorStringTable[$ErrorString]
    }
    elseif ($PSCmdlet.ParameterSetName -eq 'code2string')
    {
        $errorCodeTable = @{}

        foreach ($key in $errorStringTable.Keys)
        {
            $errorCodeTable.add($errorStringTable[$key], $key)
        }

        if ($ErrorCode -eq 0)
        {
            $errorCodeTable[0]
        }

        foreach ($errorCodeBit in $errorStringTable.Values)
        {
            if ($ErrorCode -band $errorCodeBit)
            {
                $errorCodeTable[$errorCodeBit]
            }
        }
    }
    else
    {
        [int] $returnErrorCode = 0

        if ($Action -eq 'offboard')
        {
            if (($Manifest.MDE.State -ne '') -and ($Manifest.MDE.State -ne 'not_onboarded'))
            {
                $returnErrorCode = $returnErrorCode + $errorStringTable[('{0}_offboard_failed' -f $Manifest.MDE.Agent.Type)]
            }

            if ($RemoveAgent -and $Manifest.ManifestName -notlike '*Modern' -and $Manifest.MDE.Agent.InstallState -ne 'not_installed')
            {
                $returnErrorCode = $returnErrorCode + $errorStringTable[('{0}_uninstall_failed' -f $Manifest.MDE.Agent.Type)]
            }
        }
        else
        {
            if ($Manifest.IsWindowsUpdateDisabled -eq $true)
            {
                $returnErrorCode = $returnErrorCode + $errorStringTable['wuau_disabled']
            }

            foreach ($update in $manifest.UpdateList | Where-Object -FilterScript { $_.ExitCode -ne 0 })
            {
                if ($update.FileName -eq 'manual_cu')
                {
                    $returnErrorCode = $returnErrorCode + $errorStringTable['missing_critical_cu']
                }
                elseif ($update.ExitCode -eq 3010)
                {
                    if (($returnErrorCode -band $errorStringTable['reboot_required']) -eq 0)
                    {
                        $returnErrorCode = $returnErrorCode + $errorStringTable['reboot_required']
                    }
                }
                elseif ($update.ExitCode -eq 191)
                {
                    if (($returnErrorCode -band $errorStringTable['installer_invalid_signature']) -eq 0)
                    {
                        $returnErrorCode = $returnErrorCode + $errorStringTable['installer_invalid_signature']
                    }
                }
                elseif ($update.ExitCode -ne 0x80240017)
                {
                    $kbErrorKey = ('{0}_failed' -f $update.Name)
                    $returnErrorCode = $returnErrorCode + $errorStringTable[$kbErrorKey]
                }
            }

            if ($manifest.SCEP.Remove -eq $true -and $manifest.SCEP.ExitCode -ne 0)
            {
                $returnErrorCode = $returnErrorCode + $errorStringTable['scep_uninstall_failed']
            }

            if ($Manifest.MDE.Agent.ExitCode -eq 3010)
            {
                if (($returnErrorCode -band $errorStringTable['reboot_required']) -eq 0)
                {
                    $returnErrorCode = $returnErrorCode + $errorStringTable['reboot_required']
                }
            }
            elseif ($Manifest.MDE.Agent.ExitCode -eq 191)
            {
                if (($returnErrorCode -band $errorStringTable['installer_invalid_signature']) -eq 0)
                {
                    $returnErrorCode = $returnErrorCode + $errorStringTable['installer_invalid_signature']
                }
            }
            elseif ($Manifest.MDE.Agent.InstallState -ne 'current')
            {
                $returnErrorCode = $returnErrorCode + $errorStringTable[('{0}_install_failed' -f $Manifest.MDE.Agent.Type)]
            }

            if ($Manifest.MDE.Action.ExitCode -eq $errorStringTable['workspace_key_invalid'])
            {
                $returnErrorCode = $returnErrorCode + $errorStringTable['workspace_key_invalid']
            }

            if (
                ($Manifest.MDE.Agent.Type -eq 'Legacy') -and ($Manifest.MDE.State -ne 'mma_onboarded') -or
                ($Manifest.MDE.Agent.Type -eq 'Modern') -and ($Manifest.MDE.State -ne 'onboarded')
            )
            {
                $returnErrorCode = $returnErrorCode + $errorStringTable[('{0}_onboard_failed' -f $Manifest.MDE.Agent.Type)]
            }
        }

        $returnErrorCode
    }
}


<#
    .Synopsis
        Checks the installed state of the sense service.
    .PARAMETER MinVersion
        The minimum version of the sense agent needed to address all currently known issues
    .LINK
        https://learn.microsoft.com/en-us/microsoft-365/security/defender-endpoint/configure-server-endpoints?view=o365-worldwide#workaround-for-a-known-issue-with-telemetryproxyserver-on-disconnected-machines
    .LINK
        https://support.microsoft.com/en-us/topic/microsoft-defender-for-endpoint-update-for-edr-sensor-f8f69773-f17f-420f-91f4-a8e5167284ac
#>
function Get-SenseInstallState
{
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWMICmdlet', '', Justification = 'Needs to run on Win7 and the CIM cmdlets wont be available')]
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter()]
        [version] $MinVersion = '10.8210.22621.1016'
    )

    $service = Get-WmiObject -Query 'Select Name,State from Win32_Service where Name = "Sense"'

    $return = @{
        InstallState = ''
        State        = ''
    }

    if ($null -eq $service)
    {
        $return.InstallState = 'not_installed'
        $return.State = ''
    }
    else
    {
        <#
            The sense agent can be in different places depending on what MDE updates have been applied to the endpoint.
            The default location of the sense agent using the unified agent installer is in Program Files. The location
            of the sense agent changes to ProgramData after updates are applied, but only after the endpoint is
            onboarded to MDE. The InstallLocation registry value is updated during the onboarding process, so it is only
            available after the endpoint is onboarded.
        #>

        $regPath = 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\'
        $installLocation = (Get-ItemProperty -Path $regPath -Name 'InstallLocation' -ErrorAction SilentlyContinue).InstallLocation

        if ($null -ne $installLocation)
        {
            $agentPath = Join-Path -Path $installLocation -ChildPath 'MsSense.exe'
        }
        else
        {
            $agentPath = Join-Path -Path $env:ProgramFiles -ChildPath 'Windows Defender Advanced Threat Protection\MsSense.exe'
        }

        [version] $installedVersion = (Get-Item -Path $agentPath).VersionInfo.ProductVersion

        # The modern OS versions are always considered current, because they are updated as soon as they onboard.
        if ($installedVersion -lt $MinVersion -and (Get-OS).ManifestName -notLike '*modern')
        {
            $return.InstallState = 'not_current'
        }
        else
        {
            $return.InstallState = 'current'
        }

        $return.State = $service.State
    }

    return $return
}


<#
    .Synopsis
        Looks at the provided OS object and calls the manifest for that OS. Once the manifest is loaded, the OS
        object is added to the manifest and file names are updated to reflect the architecture of the system.
        Processes the endpoint manifest to check for overall readiness to run the rest of the
        script and onboarding process.
    .Parameter Action
        Toggles the on/off boarding script details into the system manifest
#>
function Initialize-Manifest
{
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateSet('onboard', 'offboard', 'switchorg')]
        [string] $Action,

        [Parameter(Mandatory = $true)]
        [ValidateSet('all', 'modern', 'legacy')]
        [string] $Target,

        [Parameter()]
        [guid] $WorkspaceID,

        [Parameter()]
        [guid] $FromWorkspaceID
    )

    $os = Get-OS

    if (-not $os.IsSupported)
    {
        return $os
    }

    $manifest = (Get-Variable -Name ('{0}Manifest' -f $os.ManifestName)).Value
    $manifest = $manifest + $os

    $mdeStatusParameters = @{}

    if ($Action -eq 'switchorg' -and $Target -ne 'modern')
    {
        $mdeStatusParameters.Add('WorkspaceID', $FromWorkspaceID)
    }
    elseif ($WorkspaceID)
    {
        $mdeStatusParameters.Add('WorkspaceID', $WorkspaceID)
    }

    $mdeStatus = Get-MDEStatus @mdeStatusParameters

    $manifest.MDE.State = $mdeStatus.State
    $manifest.MDE.OrgId = $mdeStatus.OrgId

    $manifest.MDE.Action.Type = $Action

    $manifest
}


<#
    .Synopsis
        Mananged the install of KB's provided in the target OS Manifest
    .Parameter Update
        The update object from the OS manifest
    .Parameter Test
        Checks to see if the update is appicable to the system without installing it.
    .Notes
        Sourced from https://github.com/microsoft/mdefordownlevelserver/blob/main/Install.ps1

        WUA Success and Error Codes:
            https://docs.microsoft.com/en-us/previous-versions/windows/desktop/hh968413(v=vs.85)
#>
function Install-Update
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [psobject] $Update
    )

    $installResult = @{
        ExitCode     = ''
        InstallState = ''
    }

    if (-not (Test-MDESetupFileSignature -FilePath $Update.FilePath))
    {
        Write-LogFile -Message ('{0} install will not be attempted.' -f $Update.Name) -TypeName Error

        $installResult.ExitCode = 191
        $installResult.InstallState = 'not_installed'

        return $installResult
    }

    Write-LogFile -Message ('{0} install starting.' -f $Update.Name)

    try
    {
        if ($Update.FileName -like '.msu')
        {
            $command = @{
                FilePath     = '"{0}"' -f (Get-Command 'wusa.exe').Path
                ArgumentList = '"{0}" /quiet /norestart' -f $Update.FilePath
                Wait         = $true
                PassThru     = $true
            }
        }
        else
        {
            $command = @{
                FilePath     = '"{0}"' -f $Update.FilePath
                ArgumentList = @('/quiet', '/norestart')
                Wait         = $true
                PassThru     = $true
            }
        }

        $process = Start-Process @command

        if ($process.ExitCode -eq 0)
        {
            Write-LogFile -Message ('{0} Install success.' -f $Update.Name)
            $installResult.InstallState = 'installed'
        }
        elseif ($process.ExitCode -eq 3010)
        {
            Write-LogFile -Message ('{0} Install success, Reboot required' -f $Update.Name)
            $installResult.InstallState = 'reboot_required'
        }
        elseif ($process.ExitCode -eq 0x80240017)
        {
            # 0x80240017 = WU_E_NOT_APPLICABLE = Operation was not performed because there are no applicable updates.
            Write-LogFile -Message ('{0} not applicable.' -f $Update.Name) -TypeName Warning
            $installResult.InstallState = 'not_applicable'
        }
        else
        {
            if ([string]::IsNullOrEmpty($process.ExitCode))
            {
                $process.ExitCode = -1
            }

            Write-LogFile -Message ('{0} Install failed, Exitcode: {1}. See https://docs.microsoft.com/en-us/previous-versions/windows/desktop/hh968413(v=vs.85) for additional details.' -f $Update.Name, $process.ExitCode) -TypeName Warning
            $installResult.InstallState = 'not_installed'
        }
    }
    catch
    {
        Write-LogFile -Message ('Ignoring error/exception: {0}' -f $_) -TypeName Warning
        $installResult.InstallState = 'not_installed'
    }
    finally
    {
        $installResult.ExitCode = $process.ExitCode

        $installResult
    }
}


<#
    .SYNOPSIS
        Installs the unified MDE agent
    .PARAMETER Manifest
        OS manifest object
#>
function Install-AgentModern
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    if (-not (Test-MDESetupFileSignature -FilePath $Manifest.MDE.Agent.FilePath))
    {
        Write-LogFile -Message 'Unified Agent install will not be attempted.' -TypeName Error
        $Manifest.MDE.Agent.ExitCode = 191
    }
    else
    {
        Write-LogFile -Message 'Unified Agent install starting'

        $argumentList = @(
            '/i'
            '"{0}"' -f $Manifest.MDE.Agent.FilePath
            '/quiet'
        )

        $command = @{
            FilePath     = 'msiexec.exe'
            ArgumentList = $argumentList
            Wait         = $true
            PassThru     = $true
        }

        $process = Start-Process @command

        switch ($process.ExitCode)
        {
            0
            {
                Write-LogFile -Message 'The Unified Agent was successfully installed'
                break
            }
            3010
            {
                Write-LogFile -Message 'The Unified Agent was successfully installed. Reboot Required'
                break
            }
            default
            {
                Write-LogFile -Message ('The Unified Agent failed to install. Exit code {0}' -f $Manifest.MDE.Agent.ExitCode ) -TypeName Error
            }
        }

        if ([string]::IsNullOrEmpty($process.ExitCode))
        {
            $Manifest.MDE.Agent.ExitCode = -1
        }
        else
        {
            $Manifest.MDE.Agent.ExitCode = $process.ExitCode
        }

        $Manifest.MDE.Agent.InstallState = (Get-SenseInstallState).InstallState
    }
}


<#
    .SYNOPSIS
        Installs the MDE Unified Agent Update
    .PARAMETER Manifest
        MDE Setup manifest
    .LINK
        https://www.catalog.update.microsoft.com/Search.aspx?q=KB5005292
#>
function Install-AgentModernUpdate
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    if (-not (Test-MDESetupFileSignature -FilePath $Manifest.MDE.Agent.UpdateFilePath))
    {
        Write-LogFile -Message 'Unified Agent update install will not be attempted.' -TypeName Error

        $Manifest.MDE.Agent.UpdateExitCode = 191
    }
    else
    {
        Write-LogFile -Message 'Unified Agent update install starting'

        $command = @{
            FilePath     = '"{0}"' -f $Manifest.MDE.Agent.UpdateFilePath
            ArgumentList = @('/quiet', '/norestart')
            Wait         = $true
            PassThru     = $true
        }

        $process = Start-Process @command

        switch ($process.ExitCode)
        {
            0
            {
                Write-LogFile -Message 'The Unified Agent update was successfully installed'
                break
            }
            3010
            {
                Write-LogFile -Message 'The Unified Agent update was successfully installed. Reboot Required'
                break
            }
            default
            {
                Write-LogFile -Message ('The Unified Agent update failed to install. Exit code {0}' -f $Manifest.MDE.Agent.UpdateExitCode ) -TypeName Error
            }
        }

        if ([string]::IsNullOrEmpty($process.ExitCode))
        {
            $Manifest.MDE.Agent.UpdateExitCode = -1
        }
        else
        {
            $Manifest.MDE.Agent.UpdateExitCode = $process.ExitCode
        }

        $Manifest.MDE.Agent.InstallState = (Get-SenseInstallState).InstallState
    }
}


<#
    .Synopsis
        Processes the OS manifest data to update and onboard the device to MDE
    .Parameter Manifest
        OS manifest object
#>
function Install-AgentLegacy
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    if (-not (Test-MDESetupFileSignature -FilePath $Manifest.MDE.Agent.FilePath))
    {
        Write-LogFile -Message 'MMA install will not be attempted.' -TypeName Error

        $Manifest.MDE.Agent.ExitCode = 191
    }
    else
    {
        $action = @{
            not_installed = 'install'
            not_current   = 'upgrade'
        }

        $setupLogPath = '{0}\MMASetup.log' -f $env:TEMP

        Write-LogFile -Message ('MMA {0} starting. Log Path: {1}' -f $action[$Manifest.MDE.Agent.InstallState], $setupLogPath)

        $tempPath = (New-Item -Type 'Directory' -Path $env:TEMP -Name ([System.Guid]::NewGuid())).FullName
        $argumentList = '/Q /C /T:{0}' -f $tempPath

        # https://docs.microsoft.com/en-us/azure/azure-monitor/agents/agent-windows#install-agent-using-command-line
        $command = @{
            FilePath     = '"{0}"' -f $Manifest.MDE.Agent.FilePath
            ArgumentList = $argumentList
            Wait         = $true
            PassThru     = $true
        }

        $extract = Start-Process @command

        if ($extract.ExitCode -ne 0)
        {
            Write-LogFile -Message 'Failed to extract setup files.' -TypeName Error

            $Manifest.MDE.Agent.ExitCode = -1
            $Manifest.MDE.Agent.InstallState = (Get-MMAInstallState).InstallState

            return
        }

        $argumentList = @(
            '/i'
            '"{0}\MOMAgent.msi"' -f $tempPath
            '/qn'
            '/l*v'
            $setupLogPath
            'AcceptEndUserLicenseAgreement=1'
        )

        $command = @{
            FilePath     = 'msiexec.exe'
            ArgumentList = $argumentList
            Wait         = $true
            PassThru     = $true
        }

        $process = Start-Process @command
        Remove-Item -Path $tempPath -Recurse -ErrorAction 'SilentlyContinue'

        switch ($process.ExitCode)
        {
            0
            {
                Write-LogFile -Message ('The MMA {0} was successful.' -f $action[$Manifest.MDE.Agent.InstallState])
                break
            }
            3010
            {
                Write-LogFile -Message ('The MMA {0} was successful. Reboot Required.' -f $action[$Manifest.MDE.Agent.InstallState])
                break
            }
            default
            {
                Write-LogFile -Message ('The MMA failed to {0}. Exit code {1}' -f $action[$Manifest.MDE.Agent.InstallState], $Manifest.MDE.Agent.ExitCode ) -TypeName Error
            }
        }

        if ([string]::IsNullOrEmpty($process.ExitCode))
        {
            $Manifest.MDE.Agent.ExitCode = -1
        }
        else
        {
            $Manifest.MDE.Agent.ExitCode = $process.ExitCode
        }

        $Manifest.MDE.Agent.InstallState = (Get-MMAInstallState).InstallState
    }
}


<#
    .Synopsis
        Offboards the endpoint from MDE using either the offboarding script from the MDE portal or the MMA comobject
    .Parameter Manifest
        OS manifest object
    .Parameter Uninstall
        The type of uninstall requested
    .Parameter WorkspaceID
        The Workspace ID from the MDE portal to onboard down level endpoints
#>
function Invoke-MDEOffboard
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter()]
        [guid] $WorkspaceID,

        [Parameter()]
        [switch] $RemoveAgent
    )

    switch ($Manifest.MDE.State)
    {
        'onboarded'
        {
            Invoke-MDEOffboardModern -Manifest $Manifest

            if ($RemoveAgent -and $Manifest.ManifestName -notlike '*Modern')
            {
                Remove-AgentModern -Manifest $Manifest
            }

            break
        }
        'mma_onboarded'
        {
            Invoke-MDEOffboardLegacy -Manifest $Manifest -WorkspaceID $WorkspaceID

            if ($RemoveAgent)
            {
                Remove-AgentLegacy -Manifest $Manifest
            }

            break
        }
    }
}


<#
    .Synopsis
        Offboards the endpoint from MDE using either the offboarding script from the MDE portal or the MMA comobject
    .Parameter WorkspaceID
        The Workspace ID from the MDE portal to onboard down level endpoints
#>

function Invoke-MDEOffboardLegacy
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [guid] $WorkspaceID
    )

    Write-LogFile -Message 'Removing the MDE Workspace from the Microsoft Monitoring Agent.'

    $mmaConfig = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
    $mmaConfig.RemoveCloudWorkspace($WorkspaceID)
    Write-LogFile -Message 'Validating MDE configruation has been removed.'

    $Manifest.MDE.State = (Get-MDEStatus -WorkspaceID $WorkspaceID).State

    if ($Manifest.MDE.State -ne 'mma_onboarded')
    {
        Write-LogFile -Message 'Endpoint has successfully removed MDE Cloud Workspace from MMA.'

        if ($Manifest.MDE.State -eq 'not_onboarded')
        {
            $statusRegisteryKey = 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status'
            $statusRegisteryKeyExists = Test-Path -Path $statusRegisteryKey

            if ($statusRegisteryKeyExists)
            {
                $null = Set-ItemProperty -Path $statusRegisteryKey -Name 'OnboardingState' -Value 0 -Force -ErrorAction SilentlyContinue
            }
        }
    }
    else
    {
        Write-LogFile -Message 'Endpoint has NOT successfully removed MDE Cloud Workspace from MMA.' -TypeName Error
    }
}


<#
    .Synopsis
        Offboards the endpoint from MDE using either the offboarding script from the MDE portal or the MMA comobject
    .Parameter Manifest
        OS manifest object
#>

function Invoke-MDEOffboardModern
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    Write-LogFile -Message 'Offboarding MDE for Modern Operating Systems.'

    $command = @{
        FilePath     = (Get-Command -Name 'cmd').Path
        ArgumentList = ('/c "{0}"' -f $Manifest.MDE.Action.FilePath)
        Wait         = $true
        PassThru     = $true
    }

    $process = Start-Process @command
    $Manifest.MDE.State = (Get-MDEStatus).State

    if ([string]::IsNullOrEmpty($process.ExitCode))
    {
        $Manifest.MDE.Action.ExitCode = -1
    }
    else
    {
        $Manifest.MDE.Action.ExitCode = $process.ExitCode
    }

    $message = 'Offboard MDE for Modern Operating System exit code: {0}' -f $Manifest.MDE.Action.ExitCode

    if ($Manifest.MDE.Action.ExitCode -eq 0)
    {
        Write-LogFile -Message $message
    }
    else
    {
        Write-LogFile -Message $message -TypeName Error
    }
}


<#
    .Synopsis
        Processes the OS manifest data to update and onboard the device to MDE.
    .Parameter Manifest
        OS manifest object
    .Parameter WorkspaceID
        The Workspace ID from the MDE portal to onboard down level endpoints
    .Parameter WorkspaceKey
        The Workspace Key from the MDE portal to onboard down level endpoints
    .Parameter CloudType
        Commercial or Gov cloud
    .Parameter Proxy
        Sets the proxy for the MDE agent
    .Parameter PassiveMode
        Sets the MDE agent in Passive mode
#>
function Invoke-MDEOnboard
{
    [CmdletBinding(DefaultParameterSetName = 'all')]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $false)]
        [AllowNull()]
        [guid] $WorkspaceID,

        [Parameter(Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
        [string] $WorkspaceKey,

        [Parameter(Mandatory = $false)]
        [ValidateSet('Commercial', 'GCC', 'GCC-H', 'DOD')]
        [string] $CloudType,

        [Parameter(Mandatory = $false)]
        [uri] $Proxy,

        [Parameter(Mandatory = $false)]
        [switch] $PassiveMode,

        [Parameter()]
        [switch] $RemoveAgent
    )

    # Always need to install updates
    foreach ($update in $Manifest.UpdateList | Where-Object -FilterScript { $_.Required })
    {
        $installUpdate = Install-Update -Update $update
        $update.InstallState = $installUpdate.InstallState
        $update.ExitCode = $installUpdate.ExitCode
    }

    # Unified onboarding
    if ($Manifest.MDE.State -eq 'not_onboarded' -and $Manifest.MDE.Agent.Type -eq 'Modern')
    {
        Invoke-MDESetupModern -Manifest $Manifest -Proxy $Proxy -PassiveMode:$PassiveMode
    }

    # MMA Onboarding or Unified onboarding failed and fallback is allowed
    if (($Manifest.MDE.State -eq 'not_onboarded' -and $Manifest.MDE.Agent.Type -eq 'Legacy') -or
        ($Manifest.MDE.State -eq 'not_onboarded' -and $Manifest.MDE.Agent.Type -eq 'Modern' -and $Manifest.MDE.Agent.AllowFallback)
    )
    {
        Invoke-MDESetupLegacy -Manifest $Manifest -WorkspaceID $WorkspaceID -WorkspaceKey $WorkspaceKey -CloudType $CloudType -Proxy $Proxy
    }

    # Currently onboarded to MMA and Unified is available and Migration is enabled
    if ($Manifest.MDE.State -eq 'mma_onboarded' -and $Manifest.MDE.Agent.Type -eq 'Modern' -and -not $Manifest.MDE.Agent.AllowFallback)
    {
        if ($Manifest.MDE.Agent.AllowMigrate)
        {
            $parameters = @{
                Manifest    = $Manifest
                PassiveMode = $PassiveMode
                RemoveAgent = $RemoveAgent
            }

            if ($Proxy)
            {
                $parameters.Add('Proxy', $Proxy)
            }

            if ($WorkspaceID)
            {
                $parameters.Add('WorkspaceID', $WorkspaceID)
            }

            Invoke-MDESetupModernMigrate @parameters
        }
        else
        {
            Write-LogFile -Message 'Upgrade switch not provided, leaving MMA onboarding in place.'
        }
    }

    if ($Manifest.MDE.State -match '^(mma_)?onboarded')
    {
        $mdeRegPath = 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection'

        # To increase our chance of capturing the senseId in the log, set a retry that times out
        $sleepSeconds = 10
        $maxRetryCount = 30
        for ($retryCount = 0; $retryCount -lt $maxRetryCount; $retryCount++)
        {
            $deviceId = (Get-ItemProperty -Path $mdeRegPath -Name 'senseId' -ErrorAction SilentlyContinue).senseId
            if (-not [string]::IsNullOrEmpty($deviceId))
            {
                break
            }

            Start-Sleep -Seconds $sleepSeconds
        }

        if ([string]::IsNullOrEmpty($deviceId))
        {
            $Manifest.MDE.DeviceId = 'Not set after {0} seconds' -f ($sleepSeconds * $maxRetryCount)
        }
        else
        {
            Write-LogFile -Message ('DeviceId found after {0} seconds' -f ($sleepSeconds * $retryCount))
            $Manifest.MDE.DeviceId = $deviceId
        }

        Write-LogFile -Message ('DeviceId: {0}' -f $Manifest.MDE.DeviceId)
        $Manifest.MDE.Connectivity = Test-MDEConnectivity -AgentType $Manifest.MDE.Agent.Type
    }
}


<#
    .Synopsis
        Onboard the endpoint to MDE via MMA
    .Parameter WorkspaceID
        The Id to the workspace from the MDE portal
    .Parameter WorkspaceKey
        The key to the workspace from the MDE portal
    .Parameter CloudType
        The target cloud
    .Parameter Proxy
        The proxy the MMA should use to communicate to the MDE API
#>
function Invoke-MDEOnboardLegacy
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $WorkspaceID,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $WorkspaceKey,

        [Parameter(Mandatory = $true)]
        [ValidateSet('Commercial', 'GCC', 'GCC-H', 'DOD')]
        [string] $CloudType,

        [Parameter()]
        [uri] $Proxy
    )

    if ($null -ne $Proxy)
    {
        Set-Proxy -Proxy $Proxy -Manifest $Manifest
    }

    Write-LogFile -Message 'Configuring MMA for MDE.'
    $mma = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
    $mma.AddCloudWorkspace($WorkspaceId, $WorkspaceKey, (Resolve-CloudType -CloudType $CloudType))
    $mma.ReloadConfiguration()

    $Manifest.MDE.State = (Get-MDEStatus -WorkspaceID $WorkspaceID).State

    if ($Manifest.MDE.State -eq 'mma_onboarded')
    {
        $Manifest.MDE.Action.ExitCode = 0
        Write-LogFile -Message 'Workspace for MDE was successfully configured for MMA.'
    }
    else
    {
        $Manifest.MDE.Action.ExitCode = -1
        Write-LogFile -Message 'Workspace for MDE was not successfully configured for MMA.' -TypeName Error
    }
}


<#
    .Synopsis
        Processes the OS manifest data to update and onboard the device to MDE
    .Parameter Manifest
        OS manifest object
    .Parameter Proxy
         Sets the proxy for the MDE agent
#>
function Invoke-MDEOnboardModern
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter()]
        [uri] $Proxy
    )

    if ($null -ne $Proxy)
    {
        Set-Proxy -Proxy $Proxy -Manifest $Manifest
    }

    Write-LogFile -Message 'Onboarding MDE Unified agent.'

    $command = @{
        FilePath     = (Get-Command -Name 'cmd').Path
        ArgumentList = ('/c "{0}"' -f $Manifest.MDE.Action.FilePath)
        Wait         = $true
        PassThru     = $true
    }

    $process = Start-Process @command
    $Manifest.MDE.State = (Get-MDEStatus).State

    if ($process.ExitCode -eq 0)
    {
        $Manifest.MDE.Action.ExitCode = $process.ExitCode

        Write-LogFile -Message 'MDE Unified agent onboarding was successful.'
    }
    else
    {
        if ([string]::IsNullOrEmpty($process.ExitCode))
        {
            $Manifest.MDE.Action.ExitCode = -1
        }
        else
        {
            $Manifest.MDE.Action.ExitCode = $process.ExitCode
        }

        Write-LogFile -Message ('MDE Unified agent onboarding was not successful. ErrorCode {0}' -f $Manifest.MDE.Action.ExitCode) -TypeName Error
    }
}


function Invoke-MDESetupLegacy
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [guid] $WorkspaceID,

        [Parameter(Mandatory = $true)]
        [string] $WorkspaceKey,

        [Parameter(Mandatory = $true)]
        [ValidateSet('Commercial', 'GCC', 'GCC-H', 'DOD')]
        [string] $CloudType,

        [Parameter()]
        [uri] $Proxy
    )

    # In a fallback scenerio we need to refresh the manifest with the MMA installer details
    if ($Manifest.MDE.Agent.Type -eq 'Modern')
    {
        Update-Manifest -Manifest $Manifest -UseMMA
    }

    if ($Manifest.MDE.Agent.RequiresInstall)
    {
        Install-AgentLegacy -Manifest $Manifest
    }

    # The MMA needs to be present before validating settings, so this really only works after we verify/install it.
    if ( -not (Test-MDEConnectivity -Validate -CloudType $CloudType -WorkspaceID $WorkspaceID -WorkspaceKey $WorkspaceKey))
    {
        Write-LogFile -Message 'The Workspace key is not valid with the Workspace ID.'
        $Manifest.MDE.Action.ExitCode = Get-ReturnCode -ErrorString 'workspace_key_invalid'
        return
    }

    if ($Manifest.MDE.Agent.InstallState -eq 'current')
    {
        Invoke-MDEOnboardLegacy -Manifest $Manifest -WorkspaceID $WorkspaceID -WorkspaceKey $WorkspaceKey -CloudType $CloudType -Proxy $Proxy
    }
    else
    {
        Write-LogFile -Message 'MMA did not install sucessfully, onboarding cannot continue.'
    }
}


function Invoke-MDESetupModern
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter()]
        [switch] $PassiveMode,

        [Parameter()]
        [uri] $Proxy
    )

    if ($Manifest.SCEP.InstallState -eq 'installed' -and $Manifest.SCEP.Remove)
    {
        Remove-SCEP -Manifest $Manifest
    }

    if ($Manifest.MDE.Agent.RequiresInstall)
    {
        Install-AgentModern -Manifest $Manifest
    }

    if ($Manifest.ManifestName -like 'WindowsServer*')
    {
        $Manifest.DefenderAV = Get-DefenderAV
    }

    if ($manifest.DefenderAVForcePassive -and $PassiveMode)
    {
        Set-DefenderPassiveMode -Enabled
    }
    else
    {
        $manifest.DefenderAVForcePassive = $false
    }

    if ($Manifest.MDE.Agent.InstallState -ne 'not_installed')
    {
        Invoke-MDEOnboardModern -Manifest $Manifest -Proxy $Proxy
    }
    else
    {
        Write-LogFile -Message ('Unified agent did not install sucessfully Error Code {0}.' -f $Manifest.MDE.Agent.ExitCode)
    }

    # The sense agent installer may need an update after it is onboarded
    $Manifest.MDE.Agent.RequiresUpdate = (Get-SenseInstallState).InstallState -ne 'current'

    if ($Manifest.MDE.Agent.RequiresUpdate)
    {
        Install-AgentModernUpdate -Manifest $Manifest
    }
}


<#
    .Synopsis
        Migrates an endpoint that is onboarded via MMA to the new Unified agent
    .Parameter Manifest
        The OS Manifest to process
    .Parameter WorkspaceID
        The Workspace ID from the MDE portal to onboard down level endpoints
    .Parameter WorkspaceKey
        The Workspace Key from the MDE portal to onboard down level endpoints
    .Parameter PassiveMode
        Set Microsoft Defender Antivirus to passive mode to prevent problems caused by having multiple antivirus products
        installed on a server.
    .Parameter Proxy
        The proxy configuration to apply to the endpoint in the format "http://<proxyServer>:port"
        If a proxy is already configured on the endpoint, this value will be ignored and an alternative deployment method
        will be required
    .Parameter RemoveAgent
        When this flag is set the function will attempt to remove any MDE agents that are not native to the OS or being
        used by any other services such as SCOM.
    .Link
        https://github.com/microsoft/mdefordownlevelserver
#>
function Invoke-MDESetupModernMigrate
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter()]
        [guid] $WorkspaceID,

        [Parameter()]
        [switch] $PassiveMode,

        [Parameter()]
        [uri] $Proxy,

        [Parameter()]
        [switch] $RemoveAgent
    )

    Install-AgentModern -Manifest $Manifest

    if ($Manifest.DefenderAVForcePassive -and $PassiveMode)
    {
        Set-DefenderPassiveMode -Enabled
    }
    else
    {
        $Manifest.DefenderAVForcePassive = $false
    }

    if ($Manifest.MDE.Agent.InstallState -eq 'current')
    {
        Invoke-MDEOnboardModern -Manifest $Manifest -Proxy $Proxy
    }

    if ($Manifest.MDE.State -eq 'onboarded' -and $WorkspaceID)
    {
        Invoke-MDEOffboardLegacy -Manifest $Manifest -WorkspaceID $WorkspaceID

        if ($Manifest.MDE.State -ne 'mma_onboarded' -and $RemoveAgent)
        {
            Remove-AgentLegacy -Manifest $Manifest
        }
    }
}


<#
    .SYNOPSIS
        Processes the OS manifest data to switch the endpoint from one MDE tenant to another.
    .DESCRIPTION
        Accepts all parameters needed to orchestrate the offboard from the existing tenant and onboard to the new
        tenant in a single pass. Any existing functionality to migrate agents and update defender components are run
        in the same way they would be if a standard onboarding was requested.
#>
function Invoke-MDESwitch
{
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingInvokeExpression', '', Justification = 'Inputs are restricted.')]
    [CmdletBinding(DefaultParameterSetName = 'general')]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $true, ParameterSetName = 'general')]
        [ValidateSet('All', 'Modern', 'Legacy')]
        [string] $Target,

        [Parameter(Mandatory = $true, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $true, ParameterSetName = 'general')]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $false, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $false, ParameterSetName = 'general')]
        [guid] $FromWorkspaceID,

        [Parameter(Mandatory = $false, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $false, ParameterSetName = 'general')]
        [guid] $FromOrgID,

        [Parameter(Mandatory = $false, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $false, ParameterSetName = 'general')]
        [AllowNull()]
        [guid] $WorkspaceID,

        [Parameter(Mandatory = $false, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $false, ParameterSetName = 'general')]
        [ValidateNotNullOrEmpty()]
        [string] $WorkspaceKey,

        [Parameter(Mandatory = $true, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $true, ParameterSetName = 'general')]
        [ValidateSet('Commercial', 'GCC', 'GCC-H', 'DOD')]
        [string] $CloudType,

        [Parameter(Mandatory = $false, ParameterSetName = 'ir')]
        [Parameter(Mandatory = $false, ParameterSetName = 'general')]
        [uri] $Proxy,

        [Parameter(ParameterSetName = 'ir')]
        [Parameter(ParameterSetName = 'general')]
        [switch] $PassiveMode,

        [Parameter(ParameterSetName = 'ir')]
        [Parameter(ParameterSetName = 'general')]
        [switch] $RemoveAgent,

        [Parameter(ParameterSetName = 'ir')]
        [Parameter(ParameterSetName = 'general')]
        [switch] $MigrateToUnified,

        [Parameter(ParameterSetName = 'ir')]
        [Parameter(ParameterSetName = 'general')]
        [switch] $EnableMMAFallback,

        [Parameter(Mandatory = $true, ParameterSetName = 'ir')]
        [ValidateScript({ $_.StartsWith('ircstc') })]
        [string] $StorageAccountName,

        [Parameter(Mandatory = $true, ParameterSetName = 'ir')]
        [ValidateScript({ $_ -match '^\?sv\=\d{4}(-\d{2}){2}&sr=c&si=defaultinbound&sig=' })]
        [string] $SASToken,

        [Parameter(ParameterSetName = 'ir')]
        [Parameter(ParameterSetName = 'general')]
        [switch] $UpdateDefenderAVAll
    )

    if ($Manifest.MDE.State -ne 'not_onboarded')
    {
        Write-LogFile -Message 'Starting MDE tenant switch'

        $offboardCommand = [System.Collections.ArrayList]@(
            ($myInvocation.ScriptName -replace ' ', '` '),
            '-Offboard',
            ('-{0}' -f $Target),
            ('-CloudType ''{0}''' -f $CloudType),
            ('-FromOrgID ''{0}''' -f $FromOrgID)
        )

        if ($PSCmdlet.ParameterSetName -eq 'ir')
        {
            $null = $offboardCommand.Add('-StorageAccountName ''{0}''' -f $StorageAccountName)
            $null = $offboardCommand.Add('-SASToken ''{0}''' -f $SASToken)
        }
        if ($FromWorkspaceID)
        {
            $null = $offboardCommand.Add('-WorkspaceID ''{0}''' -f $FromWorkspaceID)
        }

        Write-LogFile -Message 'Calling script to Offboard from old tenant'

        Invoke-Expression -Command ($offboardCommand -join ' ')

        if ($LASTEXITCODE -ne 0)
        {
            Write-LogFile -Message 'System not fully Offboarded from old tenant. Can not continue tenant switch.' -TypeName Error
            return $LASTEXITCODE
        }
    }

    Write-LogFile -Message 'Calling script to Onboard to new tenant'

    $onboardCommand = [System.Collections.ArrayList]@(
        ($myInvocation.ScriptName -replace ' ', '` '),
        '-Onboard',
        ('-{0}' -f $Target),
        ('-CloudType ''{0}''' -f $CloudType)
    )

    if ($PSCmdlet.ParameterSetName -eq 'ir')
    {
        $null = $onboardCommand.Add('-StorageAccountName ''{0}''' -f $StorageAccountName)
        $null = $onboardCommand.Add('-SASToken ''{0}''' -f $SASToken)
    }
    if ($EnableMMAFallback)
    {
        $null = $onboardCommand.Add('-EnableMMAFallback')
    }

    if ($MigrateToUnified)
    {
        $null = $onboardCommand.Add('-MigrateToUnified')
    }

    if ($UpdateDefenderAVAll)
    {
        $null = $onboardCommand.Add('-UpdateDefenderAVAll')
    }

    if ($PassiveMode)
    {
        $null = $onboardCommand.Add('-PassiveMode')
    }

    if ($RemoveAgent)
    {
        $null = $onboardCommand.Add('-RemoveAgent')
    }

    if ($WorkspaceID)
    {
        $null = $onboardCommand.Add('-WorkspaceID ''{0}''' -f $WorkspaceID)
        $null = $onboardCommand.Add('-WorkspaceKey ''{0}''' -f $WorkspaceKey)
    }

    if ($null -ne $Proxy)
    {
        $null = $onboardCommand.Add('-Proxy ''{0}''' -f $Proxy)
    }

    Invoke-Expression -Command ($onboardCommand -join ' ')

    if ($LASTEXITCODE -ne 0)
    {
        Write-LogFile -Message 'System not fully Onboarded to new tenant. Can not continue tenant switch.' -TypeName Error
        return $LASTEXITCODE
    }
}


<#
    .Synopsis
        Downloads the prerequisites for MDE that are defined in DATA-UpdateMetaData.ps1
    .Parameter UpdateMetaData
        The metadata containing the prerequisite name and download URL.
#>
function Invoke-DownloadUpdates
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [HashTable] $UpdateMetaData
    )

    $verboseMessage = 'Downloaded: {0} Url: {1} statusCode: {2}'

    foreach ($fileName in $UpdateMetaData.Keys)
    {
        $downloadUrl = $UpdateMetaData[$fileName]

        try
        {
            $destinationPath = Join-Path -Path $PSScriptRoot -ChildPath $fileName
            $response = Invoke-WebRequest -Uri $downloadUrl -OutFile $destinationPath
            $statusCode = $response.StatusCode

            Unblock-File -Path $destinationPath
        }
        catch
        {
            Write-Error -Message ($verboseMessage -f $fileName , $downloadUrl, $PSItem.Exception.Message)
        }

        Write-Verbose -Message ($verboseMessage -f $fileName , $downloadUrl, $statusCode)
    }

    $cmdFileName = 'WindowsDefenderATPOnboardingScript.cmd'
    $cmdFilePath = Join-Path -Path $PSScriptRoot -ChildPath $cmdFileName

    if (-not (Test-Path -Path $cmdFilePath))
    {
        Write-Warning -Message ('The {0} file was not found in the script directory. This file is required for on and offboarding.' -f $cmdFileName)
    }
}


<#
    .Synopsis
        Uninstalls MMA from the system if it is not configured to be used by any other services.
#>
function Remove-AgentLegacy
{
    [OutputType([void])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    Write-LogFile -Message 'Removing Microsoft Monitoring Agent from endpoint.'

    $mmaConfig = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'

    if ($mmaConfig.GetManagementGroups().Count -gt 0 -or $mmaConfig.GetCloudWorkspaces().Count -gt 0)
    {
        $Manifest.MDE.Agent.ExitCode = 0
        Write-LogFile -Message 'The Microsoft Monitoring Agent is configured for additional services and will not be removed.'
    }
    else
    {
        Write-LogFile -Message 'The Microsoft Monitoring Agent is not configured for additional services.'
        $productCode = (Get-MSI -DisplayName 'Microsoft Monitoring Agent').ProductCode

        $command = @{
            FilePath     = 'msiexec.exe'
            ArgumentList = "/X $productCode /quiet /qn"
            Wait         = $true
            PassThru     = $true
        }

        $process = Start-Process @command


        if ($process.ExitCode -eq 0)
        {
            Write-LogFile -Message 'The Microsoft Monitoring Agent was successfully removed.'
        }
        else
        {
            Write-LogFile -Message ('The Microsoft Monitoring Agent was NOT successfully removed. Exit code {0}' -f $Manifest.MDE.Agent.ExitCode) -TypeName Warning
        }

        if ([string]::IsNullOrEmpty($process.ExitCode))
        {
            $Manifest.MDE.Agent.ExitCode = -1
        }
        else
        {
            $Manifest.MDE.Agent.ExitCode = $process.ExitCode
        }
    }

    $Manifest.MDE.Agent.InstallState = (Get-MMAInstallState).InstallState
}


<#
    .Synopsis
        Uninstalls the unified agent from systems
#>
function Remove-AgentModern
{
    [OutputType([void])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    Write-LogFile -Message 'Uninstalling the MDE Unified Agent.'

    $productCode = (Get-MSI -DisplayName 'Microsoft Defender for Endpoint').ProductCode

    $command = @{
        FilePath     = 'msiexec.exe'
        ArgumentList = "/X $productCode /quiet"
        Wait         = $true
        PassThru     = $true
    }

    $process = Start-Process @command
    $Manifest.MDE.Agent.InstallState = (Get-SenseInstallState).InstallState

    if ($process.ExitCode -eq 0)
    {
        $Manifest.MDE.Agent.ExitCode = $process.ExitCode
        Write-LogFile -Message 'The MDE Unified Agent was successfully removed.'
    }
    else
    {
        if ([string]::IsNullOrEmpty($process.ExitCode))
        {
            $Manifest.MDE.Agent.ExitCode = -1
        }
        else
        {
            $Manifest.MDE.Agent.ExitCode = $process.ExitCode
        }

        Write-LogFile -Message (
            'The MDE Unified Agent was NOT successfully removed. Exit code {0}' -f $Manifest.MDE.Agent.ExitCode
        ) -TypeName Warning
    }
}


function Remove-SCEP
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    $displayName = 'Microsoft Security Client'

    Write-LogFile -Message ('Uninstalling {0}.' -f $displayName)

    $scepPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Security Client'

    $scepInstall = Get-ItemProperty -Path $scepPath

    $command = @{
        FilePath     = $scepInstall.UninstallString.TrimEnd('/x').replace('"', '').Trim()
        ArgumentList = @('/u', '/s');
        Wait         = $true
        PassThru     = $true
    }

    $process = Start-Process @command

    if ($process.ExitCode -eq 0)
    {
        $Manifest.SCEP.ExitCode = $process.ExitCode
        $Manifest.SCEP.InstallState = 'not_installed'
        Write-LogFile -Message ('Uninstall of ''{0}'' was successful.' -f $displayName)
    }
    else
    {
        if ([string]::IsNullOrEmpty($process.ExitCode))
        {
            $Manifest.SCEP.ExitCode = -1
        }
        else
        {
            $Manifest.SCEP.ExitCode = $process.ExitCode
        }

        $Manifest.SCEP.InstallState = 'installed'
        Write-LogFile -Message ('Uninstall of ''{0}'' was not successful. exitcode: {1}.' -f $displayName, $Manifest.SCEP.ExitCode)
    }
}


<#
    .SYNOPSIS
        Converts the CloudType string into the associated integer.
    .PARAMETER CloudType
        The friendly CloudType name
#>
function Resolve-CloudType
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [switch] $Storage,

        [Parameter(Mandatory = $true)]
        [ValidateSet('Commercial', 'GCC', 'GCC-H', 'DOD')]
        [string] $CloudType
    )

    $cloudTypeMap = @{
        Commercial = 0
        GCC        = 1
        'GCC-H'    = 1
        DOD        = 1
    }
    $storageBaseUrlMap = @{
        Commercial = 'windows.net'
        GCC        = 'windows.net'
        'GCC-H'    = 'usgovcloudapi.net'
        DOD        = ''
    }

    if ($Storage)
    {
        return $storageBaseUrlMap[$CloudType]
    }

    return $cloudTypeMap[$CloudType]
}


<#
    .Synopsis
        Uploads the MDESetupLog.jsonl file leveraging the Net.WebClient for backwards compatability.
    .Parameter StorageAccountName
        Specifies the Azure storage account name. This can be found in the customer welcome email.
    .Parameter SASToken
        Specifies the Ingest SAS token. This can be found in the customer welcome email.
    .Parameter Manifest
        The activity manifest.
    .Parameter Proxy
        Specifies the url to a proxy server.
#>
function Send-MDELogFile
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $StorageAccountName,

        [Parameter(Mandatory = $true)]
        [string] $SASToken,

        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [ValidateSet('Commercial', 'GCC', 'GCC-H')]
        [string] $CloudType,

        [Parameter()]
        [uri] $Proxy
    )

    $webClient = New-Object -TypeName 'System.Net.WebClient'
    $webClient.Headers.Add('x-ms-blob-type', 'BlockBlob')
    $jsonlFileName = '{0}#{1}#MdeSetupLog#{2}.jsonl' -f $manifest.DomainName, $manifest.DeviceNetBIOSName, $manifest.RunGuid

    $storageBaseUrl = Resolve-CloudType -CloudType $CloudType -Storage

    $inboundUri = 'https://{0}.blob.core.{1}/inbound/{2}{3}' -f $StorageAccountName, $storageBaseUrl, [uri]::EscapeDataString($jsonlFileName), $SASToken

    $jsonlObject = ConvertTo-Jsonl -InputObject $Manifest
    $jsonLBytes = [System.Text.Encoding]::ASCII.GetBytes($jsonlObject)

    if ($null -ne $Proxy)
    {
        $webProxy = New-Object -TypeName 'System.Net.WebProxy' -ArgumentList $Proxy
        $webClient.Proxy = $webProxy
    }

    try
    {
        $webClient.UploadData($inboundUri, 'PUT', $jsonLBytes)
        Write-LogFile -Message 'Uploading manifest to storage'
    }
    catch
    {
        Write-LogFile -Message $_.Exception.Message -TypeName Error
    }
    finally
    {
        if ($null -ne $webClient)
        {
            $webClient.Dispose()
        }
    }
}


<#
    .Synopsis
        In only the most recent versions of Windows Server, does Defender automatically enable passive mode. Using the
        passivemode switch in the unified agent onboarding script does not cover all possible scenerios, so setting
        passive was moved to this central function.
    .Link
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/microsoft-defender-antivirus-compatibility?view=o365-worldwide#fn2
#>
function Set-DefenderPassiveMode
{
    [CmdletBinding()]
    [OutputType([PSObject])]
    param
    (
        [Parameter()]
        [switch] $Enabled
    )

    $path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection'
    $name = 'ForceDefenderPassiveMode'

    $passiveMode = Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue

    if ($passiveMode -ne [int]$Enabled.ToBool())
    {
        Write-LogFile -Message ('Setting Windows Defender passive mode to {0}.' -f $Enabled)

        if (-not (Test-Path -Path $path))
        {
            New-Item -Path $path | Out-Null
        }

        New-ItemProperty -Path $path -Name $name -Value ([int]$Enabled.ToBool()) -PropertyType 'DWord' -Force | Out-Null
    }
}


<#
    .Synopsis
        Populates the HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging\Group
        key to leverage RegistryDeviceTagging
    .Notes
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/machine-tags?view=o365-worldwide
#>
function Set-DeviceTag
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [string] $DeviceTag,

        [Parameter(Mandatory = $true)]
        [ValidateSet('Onboard', 'Offboard')]
        [string] $Action
    )

    $atpRegistryPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection'
    $registryDeviceTag = 'DeviceTagging'
    $registryPropertyName = 'Group'

    if ($Action -eq 'Onboard')
    {
        if (![string]::IsNullOrEmpty($DeviceTag))
        {
            $deviceTagging = New-Item -Path $atpRegistryPath -Name $registryDeviceTag -Force

            Write-LogFile -Message ('Tagging device as {0}' -f $DeviceTag)
            New-ItemProperty -Path $deviceTagging.PSPath -Name $registryPropertyName -PropertyType 'string' -Value $DeviceTag -Force | Out-Null
        }
    }
    else
    {
        $psPath = Join-Path -Path $atpRegistryPath -ChildPath $registryDeviceTag
        $currentDeviceTag = Get-ItemProperty -Path $psPath -Name $registryPropertyName -ErrorAction 'SilentlyContinue'

        if (![string]::IsNullOrEmpty($currentDeviceTag.Group))
        {
            # docs in the link above state to remove tag clear the contents of the registry key instead of removing
            Write-LogFile -Message ('Removing device tag {0}' -f $currentDeviceTag.Group)
            Set-ItemProperty -Path $currentDeviceTag.PSPath -Name $registryPropertyName -Value $null
        }
    }
}


<#
    .Synopsis
        Sets the proxy url.
    .Description
        Set the proxy. If the sense service is detected and a current proxy configuration
        is not found the proper registry keys will be configured.

        If sense is not detected MMA is assumed to be installed and will be
        updated with the proxy url.
    .Parameter Proxy
        The proxy configuration to apply to the endpoint in the format "http://<proxyServer>:port"
        Example: "http://192.168.1.1:3128"
        Example: "http://proxy.contoso.com:3128"
    .Parameter Manifest
        OS manifest object
#>
function Set-Proxy
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [ValidateScript({ $_.IsAbsoluteUri -and $_.Port -ne -1 })]
        [uri] $Proxy
    )

    if ($Manifest.MDE.Agent.Type -eq 'Modern')
    {
        $proxySettings = Get-ProxySettings

        # If proxy is set for the sense agent we will leave it alone. If it needs to be changed the recommendation is a GPO with the new settings.
        if
        (
            ($proxySettings.WinHttpSettings.State -eq $true) -or
            ($proxySettings.TelemetryProxyServer.State -eq $true -and
            $proxySettings.DisableEnterpriseAuthProxy.Value -eq '1' -and
            $proxySettings.ProxyServer.State -eq $true)
        )
        {
            Write-LogFile -Message 'A system proxy setting is currently configured on the system. Ignoring the proxy value provided'
            return
        }
        else
        {
            if ($proxySettings.TelemetryProxyServer.State -eq $false)
            {
                $telemetryProxyServerValue = '{0}:{1}' -f $Proxy.Host, $Proxy.Port

                Write-LogFile -Message ('Telemetry Proxy is being set to {0}' -f $telemetryProxyServerValue)
                New-ItemProperty -Path $proxySettings.TelemetryProxyServer.Path -Name 'TelemetryProxyServer' -PropertyType 'string' -Value $telemetryProxyServerValue -Force | Out-Null
            }

            if
            (
                ($proxySettings.DisableEnterpriseAuthProxy.State -eq $false) -or
                ($proxySettings.DisableEnterpriseAuthProxy.Value -eq '0')
            )
            {
                Write-LogFile -Message 'Disable Enterprise Auth Proxy is being set to 1'
                New-ItemProperty -Path $proxySettings.DisableEnterpriseAuthProxy.Path -Name 'DisableEnterpriseAuthProxy' -PropertyType 'string' -Value 1 -Force | Out-Null
            }

            if ($proxySettings.ProxyServer.State -eq $false)
            {
                if ($proxy.OriginalString -match ':\d{1,5}$')
                {
                    $proxyServerValue = $proxy.OriginalString
                }
                else
                {
                    $proxyServerValue = '{0}:{1}' -f $Proxy.OriginalString, $Proxy.Port
                }

                if (-not (Test-Path -Path $proxySettings.ProxyServer.Path))
                {
                    $null = New-Item -Path $proxySettings.ProxyServer.Path -Force
                }

                Write-LogFile -Message ('Microsoft Defender Antivirus Proxy is being set to {0}' -f $Proxy.OriginalString)
                New-ItemProperty -Path $proxySettings.ProxyServer.Path -Name 'ProxyServer' -PropertyType 'string' -Value $proxyServerValue -Force | Out-Null
            }
        }
    }
    else
    {
        Write-LogFile -Message ('MMA Proxy is being set to {0}' -f $Proxy.Authority)
        $mma = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
        $mma.SetProxyUrl($Proxy.Authority)
        $mma.ReloadConfiguration()
    }
}


<#
    .Synopsis
        Converts the config file propertes into script scope parameters
#>
function Set-ScriptParameters
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [string] $Path = "$PSScriptRoot\config.psd1"
    )

    $returnString = @()

    $fileName = Split-Path -Path $Path -Leaf
    $baseDirectory = Split-Path -Path $Path

    Import-LocalizedData -BindingVariable 'configuration' -BaseDirectory $baseDirectory -FileName $fileName

    $action = Set-Variable -Name 'Action' -Value $configuration.Action -Scope 1 -PassThru
    $returnString += '{0}={1}' -f $action.Name, $action.Value
    $target = Set-Variable -Name 'Target' -Value $configuration.Target -Scope 1 -PassThru
    $returnString += '{0}={1}' -f $target.Name, $target.Value

    $argumentList = $configuration.Arguments.Keys |
        Where-Object -FilterScript { -not [string]::IsNullOrEmpty($configuration.Arguments.$_) } |
            Sort-Object

    foreach ($argument in $argumentList)
    {
        $variable = Set-Variable -Name $argument -Value $configuration.Arguments.$argument -Scope 1 -PassThru
        $returnString += '{0}={1}' -f $variable.Name, $variable.Value
    }

    '{{{0}}}' -f ($returnString -join ', ')
}


<#
    .Synopsis
        Checks the WUAU service and reenables it if necessary so that updates can be installed
#>
function Set-WindowsUpdateService
{
    [CmdletBinding()]
    [OutputType([string])]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWMICmdlet', '', Justification = "The Get/Set-Service
    cmdlets in PSv2 do not return the Startmode and this needs to run on Win7 so the CIM cmdlets won't be available")]
    param ( )

    $service = Get-WmiObject -Query 'Select StartMode from Win32_Service where Name = "wuauserv"'
    if ($service.StartMode -eq 'Disabled')
    {
        Write-LogFile -Message ('Windows Update service is {0}. Reenabling.' -f $service.StartMode) -TypeName Warning
        Set-Service -Name 'wuauserv' -StartupType 'Manual'

        $service = Get-WmiObject -Query 'Select StartMode from Win32_Service where Name = "wuauserv"'
        if ($service.StartMode -ne 'Manual')
        {
            Write-LogFile -Message 'Windows Update service was not restored.' -TypeName Error
            $return = $service.StartMode
        }
    }
    else
    {
        Write-LogFile -Message ('Windows Update service set to {0}.' -f $service.StartMode)
        $return = $service.StartMode
    }

    $return
}


<#
    .Synopsis
        Starts a service and waits for the serviceStatus to be 'Running' for the specified
        time-out to expire.  Default TimeOut value is 10 seconds.
    .Parameter ServiceName
        Sepecifies the name of the service to be started.
    .Parameter TimeOut
        A TimeSpan object specifying the amount of time to wait for the service to reach the specified status.
#>
function Start-MDEService
{
    [CmdletBinding()]
    [OutputType([PSObject])]
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $Name,

        [Parameter()]
        [timespan] $TimeOut = '00:00:10',

        [Parameter()]
        [switch] $Verify
    )

    begin
    {
        $startingEAP = $ErrorActionPreference
        $ErrorActionPreference = 'SilentlyContinue'
    }
    process
    {
        try
        {
            $service = Start-Service -Name $Name -PassThru
            $service.WaitForStatus('Running', $TimeOut)
            $service.Refresh()
        }
        catch
        {
            Write-LogFile -Message ('{0} service failed to start after waiting {1} total seconds' -f $Name, $TimeOut.TotalSeconds) -TypeName Error
        }
    }
    end
    {
        $ErrorActionPreference = $startingEAP
        # We will wait 5 seconds just in case it is stopped by a 3rd party AV
        if ($Verify)
        {
            Start-Sleep -Seconds 5
            return (Get-Service -Name $Name)
        }
        else
        {
            return $service
        }
    }
}


<#
    .Synopsis
        Validates the config file that is provided can be used to execute the script
    .Parameter Path
        The psd1 configuration file.
#>
function Test-ConfigurationFile
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter()]
        [System.IO.FileInfo] $Path = "$PSScriptRoot\config.psd1"
    )

    $isValid = $true

    if (-not (Test-Path -Path $Path.FullName))
    {
        Write-Error -Message ('{0} not found.' -f $Path.FullName)
        return $false
    }

    try
    {
        Import-LocalizedData -BindingVariable 'configuration' -BaseDirectory $Path.Directory -FileName $Path.Name
    }
    catch [System.Management.Automation.ParseException]
    {
        Write-Error -Message (($Error[0].Exception.ErrorRecord.Exception.Message -split "`r`n")[0..3] -join "`r`n")
        return $false
    }
    catch
    {
        Write-Error -Message $Error[0].Exception
        return $false
    }

    $actionSet = @('Onboard', 'Offboard', 'SwitchOrg')
    if ($null -eq $configuration.Action -or $actionSet -notcontains $configuration.Action)
    {
        Write-Error -Message ('Cannot validate parameter "Action". The argument "{0}" does not belong to the set "{1}".' -f
            $configuration.Action, ($actionSet -join '","')
        )
        return $false
    }

    $targetSet = @('All', 'Modern', 'Legacy')
    if ($null -eq $configuration.Target -or $targetSet -notcontains $configuration.Target)
    {
        Write-Error -Message ('Cannot validate parameter "Target". The argument "{0}" does not belong to the set "{1}".' -f
            $configuration.Target, ($targetSet -join '","')
        )
        return $false
    }

    $mdeSetup = Get-Command -Name (Get-PSCallStack)[1].ScriptName

    $commonParameterList = @('Debug', 'ErrorAction', 'ErrorVariable', 'InformationAction', 'InformationVariable',
        'OutVariable', 'OutBuffer', 'PipelineVariable', 'Verbose', 'WarningAction', 'WarningVariable')

    # there is a special parameterset used when EnableMMAFallback is set to require MMA parameters and prevent agent migration
    if ($configuration.Arguments.EnableMMAFallback)
    {
        $target = '{0}_{1}' -f $configuration.Target, 'mmafallback'
    }
    else
    {
        $target = $configuration.Target
    }

    $parameterList = ($mdeSetup.ParameterSets | Where-Object {
            $_.Name -eq ('{0}_{1}' -f $configuration.Action, $target )
        }).Parameters | Where-Object { $commonParameterList -notcontains $_.Name }

    foreach ($parameter in $parameterList)
    {
        $parameterValue = $configuration.Arguments.($parameter.Name)

        if ($parameter.IsMandatory -and ($null -eq $parameterValue))
        {
            $isValid = $false
            Write-Error -Message ('Missing Mandatory Parameter "{0}"' -f $parameter.Name)
            continue
        }
        elseif ($null -eq $parameterValue)
        {
            # We don't need to validate parameters that are not mandatory and not provided.
            continue
        }

        switch ($parameter.Attributes | Where-Object { $_.TypeId.Name -match 'Validate' })
        {
            { $_.TypeId.Name -eq 'ValidateNotNullOrEmptyAttribute' }
            {
                if ([string]::IsNullOrEmpty($parameterValue))
                {
                    $isValid = $false
                    Write-Error ('Cannot validate parameter "{0}". The argument is null or empty.' -f
                        $parameter.Name )
                }
            }

            { $_.TypeId.Name -eq 'ValidateSetAttribute' }
            {
                if ($_.ValidValues -notcontains $parameterValue)
                {
                    $isValid = $false
                    Write-Error ('Cannot validate parameter "{0}". The argument "{1}" does not belong to the set "{2}".' -f
                        $parameter.Name, $parameterValue, ($_.ValidValues -join '","') )
                }
            }

            { $_.TypeId.Name -eq 'ValidateScriptAttribute' }
            {
                $sbString = $_.ScriptBlock.ToString().replace('$_', ('([{0}]''{1}'')' -f $parameter.ParameterType, $parameterValue))
                $sb = [ScriptBlock]::Create($sbString)

                try
                {
                    $valid = $sb.Invoke()
                }
                catch
                {
                    $valid = $false
                }

                if (-not $valid)
                {
                    $isValid = $false
                    Write-Error ('Cannot validate parameter "{0}". The validation script "{1}" did not return True.' -f
                        $parameter.Name, $sbString)
                }
            }
        }

        if ($parameter.ParameterType.Name -eq 'SwitchParameter')
        {
            try
            {
                $null = [bool]::Parse($parameterValue)
            }
            catch
            {
                $isValid = $false
                Write-Error ('Cannot validate parameter "{0}". The value "{1}" is not "True" or "false".' -f
                    $parameter.Name, $parameterValue)
            }
        }
    }

    $isValid
}


<#
    .SYNOPSIS
        A wrapper function for .Net code to enable better testing
#>
function Test-EventSourceExists
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $Source
    )

    try
    {
        [System.Diagnostics.EventLog]::SourceExists($Source)
    }
    catch
    {
        $false
    }
}



<#
    .SYNOPSIS
        First check if we are running as administrator. Second check for running in 32-bit PowerShell. If so relaunch
        in 64-bit PowerShell. This will only work if the script is launched as an argument to powershell.exe
#>
function Test-InstallEnvironment
{
    [CmdletBinding()]
    [OutputType([int])]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWMICmdlet', '', Justification = "Needs to run on Win7 so the CIM cmdlets won't be available")]
    param
    ( )

    Test-IsPowerShellCore

    if ($null -eq $PSScriptRoot)
    {
        Set-Variable -Name PSScriptRoot -Value (Split-Path -Parent -Path $PSCmdlet.MyInvocation.ScriptName) -Scope 'Script'
    }

    Test-IsAdminRole

    # Before we do any work, make sure we are executing in the best environment. Must have to work in SCCM
    $currentContext = Get-Process -Id $PID
    $wow64Architecture = $currentContext.StartInfo.EnvironmentVariables.ContainsKey('PROCESSOR_ARCHITEW6432')
    $processArchitecture = $currentContext.StartInfo.EnvironmentVariables['PROCESSOR_ARCHITECTURE']

    if ($wow64Architecture -and $processArchitecture -eq 'x86')
    {
        $cmdLine = Get-WmiObject -Class Win32_Process -Filter "ProcessId='$PID'"
        $64bitPowerShellPath = Join-Path -Path $env:windir -ChildPath 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'
        $argumentMatch = Select-String -InputObject $cmdLine.CommandLine -Pattern '(?<=powershell\.exe"\s).*'
        $scriptParameters = $argumentMatch.Matches[0].Value

        $psReLaunch = Start-Process -FilePath $64bitPowerShellPath -ArgumentList $scriptParameters -Wait -PassThru
        return $psReLaunch.ExitCode
    }
}


<#
    .Synopsis
        Checks that the current user has admin rights on the endpoint. Deployment documentation
        highlights manual onboarding as an option, but the script needs to run with admin
        rights
    .Parameter AdministratorGroupSid
        The SID of the group the current user needs to be a member of
    .Notes
        https://docs.microsoft.com/en-us/dotnet/api/system.security.principal.windowsprincipal?view=net-6.0#constructors
#>
function Test-IsAdminRole
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [string] $AdministratorGroupSid = 'S-1-5-32-544'
    )

    $currentGroupList = (
        New-Object -TypeName Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    ).Identity.Groups | Select-Object -Property 'Value' -ExpandProperty 'Value'

    if ($currentGroupList -notcontains $AdministratorGroupSid)
    {
        throw 'Script must be run as admin'
    }
}


function Test-IsPowerShellCore
{
    [CmdletBinding()]
    param ()

    if ($PSVersionTable.PSEdition -eq 'Core')
    {
        throw 'PowerShell Core is not supported, please relanch in Windows PowerShell.'
    }
}


<#
    .Synopsis
        Checks if the KB2999226 is required on the current system
    .Link
        https://www.microsoft.com/en-us/download/confirmation.aspx?id=49063
#>
function Test-KB2999226IsNeeded
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    ( )

    if (Get-HotFix -Id 'KB2999226' -ErrorAction 'SilentlyContinue')
    {
        return $false
    }

    return $true
}


<#
    .Synopsis
        Checks if the KB is required on the current system
    .Link
        https://support.microsoft.com/en-us/topic/update-for-customer-experience-and-diagnostic-telemetry-0b4f29c3-8361-b748-f862-7ecedbc57cbf
    .Notes
        Only applicable for Windows Server 2008 R2, Windows 7, Windows Server 2012 R2, Windows 8.1.
#>
function Test-KB3080149IsNeeded
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    $fileVersionTable = @{
        Windows7            = [version]'6.1.7601.18939'
        WindowsServer2k8R2  = [version]'6.1.7601.18939'
        Windows81           = [version]'6.3.9600.17958'
        WindowsServer2k12R2 = [version]'6.3.9600.17958'
    }

    $fileVersionInfo = (Get-ItemProperty -Path "$env:SystemRoot\system32\Tdh.dll" -Name 'VersionInfo').VersionInfo
    [version] $fileVersion = ('{0}.{1}.{2}.{3}' -f $fileVersionInfo.FileMajorPart, $fileVersionInfo.FileMinorPart, $fileVersionInfo.FileBuildPart, $fileVersionInfo.FilePrivatePart)

    if ($fileVersion -lt $fileVersionTable[$Manifest.ManifestName])
    {
        return $true
    }

    return $false
}


<#
    .Synopsis
        Checks if the KB is required on the current system
    .Link
        https://support.microsoft.com/en-us/topic/support-for-tls-system-default-versions-included-in-the-net-framework-3-5-1-on-windows-7-sp1-and-server-2008-r2-sp1-5ef38dda-8e6c-65dc-c395-62d2df58715a
    .Link
        https://docs.microsoft.com/en-us/dotnet/framework/migration-guide/how-to-determine-which-versions-are-installed#detect-net-framework-45-and-later-versions
    .Notes
        Only applicable for Windows Server 2008 R2, Windows 7 SP1 Enterprise, and Windows 7 SP1 Pro.
#>
function Test-KB3154518IsNeeded
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    ( )

    $dotNetVersionPath = 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    [version] $dotNetVersion = (Get-ItemProperty -Path $dotNetVersionPath -Name 'Version' -ErrorAction SilentlyContinue).Version

    if ($dotNetVersion -gt [version]'4.5')
    {
        return $false
    }
    else
    {
        if (Get-HotFix -Id 'KB3154518' -ErrorAction 'SilentlyContinue')
        {
            return $false
        }
        else
        {
            return $true
        }
    }
}


<#
    .Synopsis
        Checks if the current system has been updated to the minimum security rollup
    .Link
        https://support.microsoft.com/en-us/topic/february-13-2018-kb4074598-monthly-rollup-71d8cade-66ea-9646-8cf4-bad3d09a2cd6
    .Notes
        Only applicable for Windows Server 2008 R2, Windows 7 SP1 Enterprise, and Windows 7 SP1 Pro.
        # TODO Important Please apply KB4100480 immediately after applying this update.
        KB4100480 resolves an elevation of privilege vulnerability in the Windows Kernel for the 64-Bit (x64) version of Windows.
        This vulnerability is documented in CVE-2018-1038.
#>
function Test-KB4074598IsNeeded
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    ( )
    # The Feb 2018 rollup is a 234MB download and is not included in our default list of updates.
    # http://download.windowsupdate.com/c/msdownload/update/software/secu/2018/02/windows6.1-kb4074598-x64_87a0c86bfb4c01d9c32d2cd3717b73c1b83cb798.msu
    # Requires a reboot
    # Testing a clean build of Windows 6.1 with SP1
    # Before KB4074598 6.1.7601.17514
    # After  KB4074598 6.1.7601.24024

    [version] $ntoskrnlVersion = (Get-ItemProperty -Path $env:windir\system32\ntoskrnl.exe).VersionInfo.ProductVersion

    if ($ntoskrnlVersion -ge [version]'6.1.7601.24024')
    {
        return $false
    }

    return $true
}


<#
    .Synopsis
        Checks if the current system has been updated to the minimum security rollup
    .Link
        https://support.microsoft.com/en-us/topic/september-14-2021-kb5005573-os-build-14393-4651-48853795-3857-4485-a2bf-f15b39464b41
    .Notes
        Only applicable for Windows 10, version 1607, all editions Windows Server 2016
        The September 2021 rollup is a 1.6GB download and is not included in our default list of updates.
        http://download.windowsupdate.com/d/msdownload/update/software/secu/2021/09/windows10.0-kb5005573-x64_68ae94716592a0f0585b0741ab94840d5b9957de.msu
        Requires a reboot
#>
function Test-KB5005573IsNeeded
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    ( )

    $ntoskrnlPath = '{0}\system32\ntoskrnl.exe' -f $env:windir
    [version] $ntoskrnlVersion = (Get-ItemProperty -Path $ntoskrnlPath).VersionInfo.ProductVersion

    if ($ntoskrnlVersion -ge [version]'10.0.14393.4651')
    {
        return $false
    }

    return $true
}


<#
    .Synopsis
        Checks if the current system has been updated to the minimum security rollup
    .Link
        https://support.microsoft.com/en-us/topic/october-12-2021-kb5006714-monthly-rollup-4dc4a2cd-677c-477b-8079-dcfef2bda09e
#>
function Test-KB5006714IsNeeded
{
    [OutputType([bool])]
    param
    ( )

    $ntoskrnlPath = '{0}\system32\ntoskrnl.exe' -f $env:windir
    [version] $ntoskrnlVersion = (Get-ItemProperty -Path $ntoskrnlPath).VersionInfo.ProductVersion
    $minimumkernalVersion = '6.3.9600.20144'

    if ([version]$ntoskrnlVersion -lt [version]$minimumkernalVersion)
    {
        return $true
    }

    return $false
}


<#
    .SYNOPSIS
        Checks if the client can communicate with required cloud endpoints.
        If the MMA connection details are provided, the Workspace Key is validated.
    .PARAMETER AgentType
        The agent in use on the endpoint to test
    .PARAMETER Validate
        Toggles the MMA configuration validation.
    .PARAMETER WorkspaceKey
        The Workspace Key to validate against the Workspace ID and Cloud Type
    .PARAMETER WorkspaceID
        The Workspace ID the Workspace Key is validated against.
    .PARAMETER CloudType
        The Cloud Type the Workspace Key is validated against.
#>
function Test-MDEConnectivity
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = 'test')]
        [ValidateSet('Modern', 'Legacy')]
        [string] $AgentType,

        [Parameter(ParameterSetName = 'Validate')]
        [switch] $Validate,

        [Parameter(Mandatory = $true, ParameterSetName = 'Validate')]
        [string] $WorkspaceKey,

        [Parameter(Mandatory = $true, ParameterSetName = 'Validate')]
        [guid] $WorkspaceID,

        [Parameter(Mandatory = $true, ParameterSetName = 'Validate')]
        [ValidateSet('Commercial', 'GCC', 'GCC-H', 'DOD')]
        [string] $CloudType
    )

    $connectivity = @{
        Status  = 'Ok'
        Details = @{}
    }

    if ($AgentType -eq 'Modern')
    {
        $mdeRegPath = 'HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection'
        $onboardedInfo = (Get-ItemProperty -Path $mdeRegPath -Name 'OnboardedInfo' -ErrorAction SilentlyContinue).OnboardedInfo
        # ConvertFrom-Json does not exist in PSv2, format the string for PSv2 ConvertFrom-StringData can be used
        $onboardedInfo = $onboardedInfo -replace '^{"body":"{|}".*|\\|"', '' -replace ',', "`r`n" -replace ':', ' = '
        $onboardedInfoBody = ConvertFrom-StringData -StringData $onboardedInfo

        if ($onboardedInfoBody.vortexGeoLocation -eq 'FFL4')
        {
            $region = $onboardedInfoBody.vortexGeoLocation + $onboardedInfoBody.Datacenter.Substring(0, 5)
        }
        else
        {
            $region = $onboardedInfoBody.vortexGeoLocation
        }

        $urlTypeList = $MDERegionList[$region]

        if ($region -notmatch 'FFL')
        {
            $urlTypeList = $urlTypeList + $MDERegionList['All']
        }

        $webRequestParams = @{
            Uri             = ''
            UseBasicParsing = $true
        }

        $proxySettings = Get-ProxySettings
        if
        (
            $proxySettings.WinHttpSettings.State -eq $false -and
            $proxySettings.ProxyServer.State -eq $true
        )
        {
            $webRequestParams.Add('Proxy', $proxySettings.ProxyServer.Value)
        }

        foreach ($urlType in $urlTypeList.GetEnumerator())
        {
            $connectivity.Details.Add($urlType.Key, 'Failed')
            foreach ($url in $urlType.Value)
            {
                $webRequestParams.Uri = $url
                $webRequest = Invoke-WebRequest @webRequestParams

                if ($webRequest.StatusCode -eq 200)
                {
                    $connectivity.Details.($urlType.Key) = 'Ok'
                    Write-LogFile -Message ('{0} : Ok' -f $urlType.Key)
                    # if any of the urls return 200 the agent can communicate with the service
                    break
                }
            }

            if ($connectivity.Details[$urlType.Key] -eq 'Failed')
            {
                $connectivity.Status = 'Failed'
                Write-LogFile -Message ('{0} : Failed' -f $urlType.Key)
            }
        }
    }
    else
    {
        $dotNetVersionPath = 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
        [version] $dotNetVersion = (Get-ItemProperty -Path $dotNetVersionPath -Name 'Version' -ErrorAction SilentlyContinue).Version
        $dotNetReady = $true
        if ($dotNetVersion -lt [version]'4.0')
        {
            $dotNetReady = $false
        }

        $mmaTestProcess = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\TestCloudConnection.exe"

        $testCloudConnectionFound = $true
        if (-not (Test-Path -Path $mmaTestProcess))
        {
            $testCloudConnectionFound = $false
        }

        if ($testCloudConnectionFound -and $dotNetReady)
        {
            $ps = New-Object -TypeName 'System.Diagnostics.Process'
            $ps.StartInfo.Filename = $mmaTestProcess
            if ($Validate)
            {
                $cloudTypeInt = Resolve-CloudType -CloudType $CloudType
                $ps.StartInfo.Arguments = ('-w {0} -k {1} -t {2}' -f $WorkspaceID, $WorkspaceKey, $cloudTypeInt)
            }
            $ps.StartInfo.RedirectStandardOutput = $True
            $ps.StartInfo.UseShellExecute = $false
            $ps.Start() | Out-Null
            $ps.WaitForExit()
            $testOMSResult = $ps.StandardOutput.ReadToEnd()
        }

        if ($Validate)
        {
            return $testOMSResult -notmatch 'The workspace key was invalid|The command line was not valid'
        }
        else
        {
            $mmaTestSuite = @{
                AgentSvc       = '(?:^\s*[\dA-F]{8}-(?:[\dA-F]{4}[-]){3}[\dA-F]{12}(?:\.agentsvc\.azure-automation\.net))(?<error>.*)?'
                Advisor        = '(?:^\s*\d{1,}advisor(?:\.blob\.core\.(?:usgovcloudapi|windows)\.net))(?<error>.*)'
                AdvisorContent = '(?:^\s*\w{1,}advisorcontent\.blob\.core\.(?:usgovcloudapi|windows)\.net)(?<error>.*)?'
                OMSSA          = '(?:^\s*\w{1,}omssa\.blob\.core\.(?:usgovcloudapi|windows)\.net)(?<error>.*)?'
                ODS            = '(?:^\s*[\dA-F]{8}-(?:[\dA-F]{4}[-]){3}[\dA-F]{12}(?:\.ods\.opinsights\.azure\.com))(?<error>.*)?'
                OMS            = '(?:^\s*[\dA-F]{8}-(?:[\dA-F]{4}[-]){3}[\dA-F]{12}(?:\.oms\.opinsights\.azure\.com))(?<error>.*)?$'
            }

            foreach ($mmaTest in $mmaTestSuite.GetEnumerator())
            {
                $testResult = $testOMSResult -split "`r`n" | Select-String -Pattern $mmaTest.Value

                $messageBase = 'OMS channel: {0} ' -f $mmaTest.Key
                if (-not $dotNetReady)
                {
                    $mmaTestResult = '.Net 4.0 or greater required. "{0}" installed' -f $dotNetVersion
                    Write-LogFile -Message ($messageBase + $mmaTestResult) -TypeName Warning
                }
                elseif (-not $testCloudConnectionFound)
                {
                    $mmaTestResult = 'TestCloudConnection.exe was not found on system'
                    Write-LogFile -Message ($messageBase + $mmaTestResult) -TypeName Warning
                }
                elseif ($null -eq $testResult)
                {
                    $mmaTestResult = 'Test not found'
                    Write-LogFile -Message ($messageBase + $mmaTestResult) -TypeName Warning
                }
                else
                {
                    $mmaTestResult = $testResult.Matches[0].Groups['error']

                    if ([string]::IsNullOrEmpty($mmaTestResult))
                    {
                        $mmaTestResult = 'Ok'
                        Write-LogFile -Message ($messageBase + $mmaTestResult)
                    }
                    else
                    {
                        $mmaTestResult = $mmaTestResult.ToString().Trim()
                        Write-LogFile -Message ($messageBase + $mmaTestResult) -TypeName Error
                    }
                }

                if ($mmaTestResult -ne 'Ok')
                {
                    $connectivity.Status = 'Failed'
                }

                $connectivity.Details.Add($mmaTest.Key, $mmaTestResult)
            }
        }
    }

    $connectivity
}


<#
    .SYNOPSIS
        Validates any external files that are called by the script
    .PARAMETER FilePath
        The full file path that will be called
#>
function Test-MDESetupFileSignature
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $FilePath
    )

    if (Test-Path -Path $FilePath -ErrorAction SilentlyContinue)
    {
        $authenticodeSig = Get-AuthenticodeSignature -FilePath $FilePath
        $issuer = $authenticodeSig.SignerCertificate.Issuer

        if ($authenticodeSig.Status -ne 'Valid')
        {
            Write-LogFile -Message ('A valid signature was not found for {0}' -f $FilePath) -TypeName 'Error'
            return $false
        }

        if (($issuer -ne 'CN=Microsoft Code Signing PCA 2011, O=Microsoft Corporation, L=Redmond, S=Washington, C=US') -and
            ($issuer -ne 'CN=Microsoft Windows Production PCA 2011, O=Microsoft Corporation, L=Redmond, S=Washington, C=US') -and
            ($issuer -ne 'CN=Microsoft Code Signing PCA, O=Microsoft Corporation, L=Redmond, S=Washington, C=US') -and
            ($issuer -ne 'CN=Microsoft Code Signing PCA 2010, O=Microsoft Corporation, L=Redmond, S=Washington, C=US') -and
            ($issuer -ne 'CN=Microsoft Development PCA 2014, O=Microsoft Corporation, L=Redmond, S=Washington, C=US')
        )
        {
            Write-LogFile -Message ('{0} is not signed by Microsoft' -f $FilePath) -TypeName 'Error'
            return $false
        }

        Write-LogFile -Message 'Signature is valid and signed by Microsoft'
        return $true
    }
    else
    {
        Write-LogFile -Message ('Path {0} was not found' -f $FilePath) -TypeName 'Error'
        return $false
    }
}


<#
    .Synopsis
        Checks if the Windows Defender security intelligence update is required by the OS or requested by the customer
    .Parameter Manifest
        The endpoint deployment manifest
    .Link
        https://www.microsoft.com/en-us/wdsi/defenderupdates
#>
function Test-MpamFeIsNeeded
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    $mpamFe = $Manifest.UpdateList | Where-Object -FilterScript { $_.Name -eq 'MpamFe' }

    if ($mpamFe.Required -or $Manifest.DefenderAVUpdateEnabled)
    {
        return $true
    }

    return $false
}


<#
    .Synopsis
        Determines if the endpoint should be offboarded based on the current state and parameters provided
    .Parameter Manifest
        The OS manifest
    .Parameter Target
        The OS target that should be offboarded
#>
function Test-ShouldOffboard
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [ValidateSet('All', 'Modern', 'Legacy')]
        [string] $Target
    )

    if ($Manifest.MDE.State -eq 'not_onboarded')
    {
        return @{
            Message = 'Endpoint is not onboarded.'
            Result  = $false
        }
    }
    else
    {
        $shouldOnboardMessage = '{0} Endpoints are in scope and device is currently {1}.'
        switch ($Target)
        {
            'All'
            {
                return @{
                    Message = ($shouldOnboardMessage -f $_, $Manifest.MDE.State)
                    Result  = $true
                }
            }
            { $_ -eq 'Modern' -and $Manifest.MDE.State -eq 'onboarded' }
            {
                return @{
                    Message = ($shouldOnboardMessage -f $_, $Manifest.MDE.State)
                    Result  = $true
                }
            }
            { $_ -eq 'Legacy' -and $Manifest.MDE.State -eq 'mma_onboarded' }
            {
                return @{
                    Message = ($shouldOnboardMessage -f $_, $Manifest.MDE.State)
                    Result  = $true
                }
            }
            default
            {
                return @{
                    Message = ('Not in scope, {0} Endpoints are in scope and device is currently {1}.' -f $_, $Manifest.MDE.State)
                    Result  = $false
                }
            }
        }
    }
}


<#
    .SYNOPSIS
        Determines if the endpoint should be offboarded based on the current state and parameters provided
    .PARAMETER Manifest
        The OS manifest
    .PARAMETER Target
        The OS target that should be offboarded
#>
function Test-ShouldOnboard
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [ValidateSet('All', 'Modern', 'Legacy')]
        [string] $Target,

        [Parameter()]
        [switch] $MigrateToUnified
    )

    if (
        $Target -eq 'All' -or
        $Target -eq $Manifest.MDE.Agent.Type
    )
    {
        if (
            ($manifest.MDE.State -eq 'onboarded' -and $manifest.MDE.Agent.Type -eq 'Modern') -or
            ($manifest.MDE.State -eq 'mma_onboarded' -and $manifest.MDE.Agent.Type -eq 'Legacy') -or
            ($manifest.MDE.State -eq 'mma_onboarded' -and $manifest.MDE.Agent.Type -eq 'Modern' -and -not $MigrateToUnified)
        )
        {
            return @{
                Message = 'Already onboarded with the correct agent.'
                Result  = $false
            }
        }
        else
        {
            return @{
                Message = 'OS is in scope and not currently onboarded.'
                Result  = $true
            }
        }
    }
    else
    {
        return @{
            Message = 'OS is not currently in scope.'
            Result  = $false
        }
    }
}


<#
    .SYNOPSIS
        Checks for the the run file to determine if the script should run again.
    .NOTES
        The run file that is used in other solutions, will eventually cause problems becasue if the run file and the actual
        state of MDE get out of sync then we will have no way of triggering the script in the future fo things lile upgrade
        and offboard.
#>
function Test-ShouldRun
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [ValidateSet('All', 'Modern', 'Legacy')]
        [string] $Target,

        [Parameter()]
        [switch] $MigrateToUnified,

        [Parameter()]
        [guid] $FromOrgID
    )

    if (-not $Manifest.IsSupported)
    {
        return @{
            Message = '{0} is not an OS that is supported by MDE.' -f $Manifest.OSName
            Result  = $false
        }
    }

    switch ($Manifest.MDE.Action.Type)
    {
        'onboard'
        {
            Test-ShouldOnboard -Manifest $Manifest -Target $Target -MigrateToUnified:$MigrateToUnified
        }
        'offboard'
        {
            Test-ShouldOffboard -Manifest $Manifest -Target $Target
        }
        'switchorg'
        {
            Test-ShouldSwitch -Manifest $Manifest -FromOrgID $FromOrgID
        }
    }
}


<#
    .SYNOPSIS
        Determines if the endpoint should switch from an existing tenant based on the current state (OrgId)
    .PARAMETER Manifest
        The OS manifest
    .PARAMETER FromOrgID
        The OrgId of the tenant that the endpoint should switch from
#>
function Test-ShouldSwitch
{
    [CmdletBinding()]
    [OutputType([hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter(Mandatory = $true)]
        [guid] $FromOrgID
    )

    if ($Manifest.MDE.State -eq 'not_onboarded')
    {
        return @{
            Message = 'Endpoint is not onboarded to an MDE tenant.'
            Result  = $true
        }
    }
    elseif ($Manifest.MDE.State -match '^(mma_)?onboarded' -and $Manifest.MDE.OrgID -eq $FromOrgID)
    {
        return @{
            Message = 'Endpoint is onboarded to old MDE tenant.'
            Result  = $true
        }
    }
    else
    {
        return @{
            Message = 'Endpoint is onboarded to MDE.'
            Result  = $false
        }
    }
}


<#
    .Synopsis
        Checks if the Windows Defender Antivirus platform update is required by the OS or requested by the customer
    .Parameter Manifest
        The endpoint deployment manifest
    .Link
        https://support.microsoft.com/en-us/topic/update-for-microsoft-defender-antimalware-platform-92e21611-8cf1-8e0e-56d6-561a07d144cc
#>
function Test-UpdatePlatformIsNeeded
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    $updatePlatform = $Manifest.UpdateList | Where-Object -FilterScript { $_.Name -eq 'UpdatePlatform' }

    if ($updatePlatform.Required -or $Manifest.DefenderAVUpdateEnabled)
    {
        return $true
    }

    return $false
}


<#
    .Synopsis
        When an endpoint is being onboarded to Unified or migrated from MMA to the Unified agent, there are several
        failure points. The manifest will initially be set to install the Unified agent, but needs to be updated after
        a failure occurs if fallback is allowed. This function will update the manifest so that the endpoint can be
        prepared for and onboarded via MMA.
    .Parameter Manifest
        The OS manifest that contains the list of tasks as well as the status of each task
    .Parameter UseMMA
        A flag that tells the function to update the manifest to use the MMA instead of the Unified agent.
#>
function Update-Manifest
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter()]
        [switch] $UseMMA
    )

    if ($UseMMA)
    {
        $Manifest.MDE.Agent.Type = 'Legacy'
        $Manifest.MDE.Agent.InstallState = (Get-MMAInstallState).InstallState

        if ($Manifest.MDE.Agent.InstallState -ne 'current')
        {
            $Manifest.MDE.Agent.RequiresInstall = $true

            $Manifest.MDE.Agent.FileName = ('MMASetup-{0}.exe' -f $Manifest.Architecture)

            Write-LogFile -Message ('{0} required.' -f $Manifest.MDE.Agent.FileName)

            $filePath = Get-OnboardingFile -FileName $Manifest.MDE.Agent.FileName

            if ($filePath)
            {
                $Manifest.MDE.Agent.FilePath = $filePath
            }
            else
            {
                $Manifest.Error = $true
            }
        }
        else
        {
            $Manifest.MDE.Agent.RequiresInstall = $false
        }
    }
}


<#
    .SYNOPSIS
        Processes the manifest to prepare the endpoint for MDE Offboarding.
    .PARAMETER Manifest
        The core manifest to be processed
    .PARAMETER FromOrgID
        The OrgId of the tenant that the endpoint should switch from
#>
function Update-ManifestToOffboard
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter()]
        [guid] $FromOrgID,

        [Parameter()]
        [switch] $RefreshFiles
    )

    if ($FromOrgID)
    {
        $fileName = 'WindowsDefenderATPOffboardingScript_from.cmd'
    }
    else
    {
        # System updates are not needed for the offboard if not moving to a different tenant.
        $Manifest.UpdateList = @()
        $Manifest.SCEP = @{}
        $Manifest.DefenderAV = @{}
        $fileName = 'WindowsDefenderATPOffboardingScript.cmd'
    }

    # we only need the offboarding script for unified onboarded devices
    if ($Manifest.MDE.State -eq 'onboarded')
    {
        Write-LogFile -Message ('{0} required.' -f $fileName)

        $filePath = Get-OnboardingFile -FileName $fileName -Refresh:$RefreshFiles

        if ($filePath)
        {
            $Manifest.MDE.Action.FilePath = $filePath
        }
        else
        {
            $Manifest.Error = $true
        }
    }
}


<#
    .Synopsis
        Processes the manifest to prepare the endpoint for MDE Onboarding.
    .Parameter Manifest
        The core manifest to be processed.
    .Parameter Upgrade
        Allows 2012R2 or 2016 servers that are MMA onboarded to be migrated to the unified agent.
    .Parameter EnableMMAFallback
        Allows 2012R2 or 2016 onboarding to fallback to MMA if unified setup fails for any reason.
    .Parameter UpdateDefenderAVAll
        Updates the Defender AV engine and threat intel on all modern endpoints even if they are using third party AV.
#>
function Update-ManifestToOnboard
{
    [CmdletBinding()]
    [OutputType([void])]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest,

        [Parameter()]
        [switch] $Upgrade,

        [Parameter()]
        [switch] $EnableMMAFallback,

        [Parameter()]
        [switch] $UpdateDefenderAVAll,

        [Parameter()]
        [switch] $RefreshFiles
    )

    if ((Set-WindowsUpdateService) -eq 'disabled')
    {
        $Manifest.IsWindowsUpdateDisabled = $true
    }

    if ($Manifest.UpdateList.Count -gt 0)
    {
        if ($Manifest.IsWindowsUpdateDisabled)
        {
            $Manifest.Error = $true
        }

        foreach ($update in $Manifest.UpdateList)
        {
            # Apply the architecture to required update installers
            $update.FileName = $update.FileName -f $Manifest.Architecture

            $kbTestComamnd = Get-Command -Name ('Test-{0}IsNeeded' -f $update.Name)

            if ($kbTestComamnd.Parameters.ContainsKey('Manifest'))
            {
                $update.Required = & $kbTestComamnd -Manifest $Manifest
            }
            else
            {
                $update.Required = & $kbTestComamnd
            }

            if ($update.Required)
            {
                if ($update.FileName -eq 'manual_cu')
                {
                    if ($Manifest.MDE.Agent.Type -eq 'Legacy' -or ($Manifest.MDE.Agent.Type -eq 'Modern' -and $EnableMMAFallback -eq $false))
                    {
                        Write-LogFile -Message ('{0} or newer required. Manual install required.' -f $update.Name) -TypeName Error
                        $update.ExitCode = -2147467259
                        $Manifest.Error = $true
                    }
                    else
                    {
                        Write-LogFile -Message 'Modern prereqs not met and EnableMMAFallback is true. Setting agent to Legacy.'
                        $Manifest.MDE.Agent.Type = 'Legacy'
                        $update.Required = $false
                    }
                }
                else
                {
                    Write-LogFile -Message ('{0} required.' -f $update.Name)
                    $filePath = Get-OnboardingFile -FileName $update.FileName

                    if ($filePath)
                    {
                        $update.FilePath = $filePath
                    }
                    else
                    {
                        $Manifest.Error = $true
                    }
                }
            }
            else
            {
                $update.InstallState = 0
                Write-LogFile -Message ('{0} installed.' -f $update.Name)
            }
        }
    }

    if ($Manifest.MDE.Agent.Type -eq 'Modern')
    {
        if ($UpdateDefenderAVAll)
        {
            $Manifest.DefenderAVUpdateEnabled = $true
        }

        $Manifest.MDE.Agent.InstallState = (Get-SenseInstallState).InstallState

        $agent = @{
            FileName       = 'md4ws.msi'
            UpdateFileName = 'updatesenseclient.exe'
        }

        switch ($Manifest.MDE.Agent.InstallState)
        {
            'current'
            {
                $Manifest.MDE.Agent.RequiresInstall = $false
                $Manifest.MDE.Agent.RequiresUpdate = $false
            }
            'not_current'
            {
                $Manifest.MDE.Agent.RequiresInstall = $false
                $Manifest.MDE.Agent.RequiresUpdate = $true
            }
            'not_installed'
            {
                $Manifest.MDE.Agent.RequiresInstall = $true
                $Manifest.MDE.Agent.RequiresUpdate = $true
            }
        }

        Write-LogFile -Message ('Microsoft Defender for Endpoint is {0}' -f ($Manifest.MDE.Agent.InstallState -replace '_', ' '))

        $onboardingFileName = 'WindowsDefenderATPOnboardingScript.cmd'

        Write-LogFile -Message ('{0} required.' -f $onboardingFileName)

        $Manifest.MDE.Action.FilePath = Get-OnboardingFile -FileName $onboardingFileName -Refresh:$RefreshFiles

        if ($null -eq $Manifest.MDE.Action.FilePath)
        {
            $Manifest.Error = $true
        }

        # Only update the manifest for an OS that does not natively support the unified agent
        if ($Manifest.ManifestName -notlike '*Modern')
        {
            $Manifest.MDE.Agent.AllowFallback = $EnableMMAFallback
            $Manifest.MDE.Agent.AllowMigrate = $Upgrade
        }
    }

    if ($Manifest.MDE.Agent.Type -eq 'Legacy')
    {
        $Manifest.MDE.Agent.InstallState = (Get-MMAInstallState).InstallState

        $agent = @{
            FileName       = 'MMASetup-{0}.exe' -f $Manifest.Architecture
            UpdateFileName = $null
        }

        switch ($Manifest.MDE.Agent.InstallState)
        {
            'current'
            {
                $Manifest.MDE.Agent.RequiresInstall = $false
                $Manifest.MDE.Agent.RequiresUpdate = $false
            }
            'not_current'
            # MMA Install and Update are the same process
            {
                $Manifest.MDE.Agent.RequiresInstall = $true
                $Manifest.MDE.Agent.RequiresUpdate = $false
            }
            'not_installed'
            {
                $Manifest.MDE.Agent.RequiresInstall = $true
                $Manifest.MDE.Agent.RequiresUpdate = $false
            }
        }

        Write-LogFile -Message ('MMA is {0}' -f ($Manifest.MDE.Agent.InstallState -replace '_', ' '))
    }

    if ($Manifest.ManifestName -like 'WindowsServer*')
    {
        $Manifest.DefenderAV = Get-DefenderAV
    }

    if ($Manifest.SCEP.Remove)
    {
        $scep = Get-MSI -DisplayName 'Microsoft Security Client'

        if ($scep)
        {
            $Manifest.SCEP.InstallState = 'installed'
        }
        else
        {
            $Manifest.SCEP.InstallState = 'not_installed'
            $Manifest.SCEP.Remove = $false
        }
    }

    if ($Manifest.MDE.Agent.RequiresInstall)
    {
        Write-LogFile -Message ('{0} required.' -f $agent.FileName)

        $Manifest.MDE.Agent.FileName = $agent.FileName
        $Manifest.MDE.Agent.FilePath = Get-OnboardingFile -FileName $Manifest.MDE.Agent.FileName

        if ($null -eq $Manifest.MDE.Agent.FilePath)
        {
            $Manifest.Error = $true
        }
    }

    if ($Manifest.MDE.Agent.RequiresUpdate)
    {
        Write-LogFile -Message ('{0} required.' -f $agent.UpdateFileName)
        $Manifest.MDE.Agent.UpdateFileName = $agent.UpdateFileName
        $Manifest.MDE.Agent.UpdateFilePath = Get-OnboardingFile -FileName $Manifest.MDE.Agent.UpdateFileName

        if ($null -eq $Manifest.MDE.Agent.UpdateFilePath)
        {
            $Manifest.Error = $true
        }
    }
}


<#
    .SYNOPSIS
        Central logging function to track progress.
    .PARAMETER Message
        The message data entered into the log.
    .PARAMETER TypeName
        Possible values are Normal, Warning, and Error.
        Normal is the default.
    .PARAMETER LogFileRootPath
        Specifies the root of the logging path.  This parameter defaults to env:SystemRoot
        but will be used to point to a different root path during testing.
    .PARAMETER ScanTime
        Specifies the time the log file was first created.
    .NOTES
        The single instance of the log file name is set at the global scope to simplify recursion when the script
        calls itself during a tenant switch operation, which is just an offboard of the old tenant followed by
        an onboard to the new tenant.
#>
function Write-LogFile
{
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidGlobalVars', '', Justification = 'The log path is global for recursive script execution to use the same log file.')]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $Message,

        [Parameter()]
        [ValidateSet('Normal', 'Warning', 'Error')]
        [string] $TypeName = 'Normal',

        [Parameter()]
        [string] $LogFileRootPath = $env:SystemRoot
    )

    if ([string]::IsNullOrEmpty($global:scriptStartTime))
    {
        $global:scriptStartTime = Get-Date -Format 'MMddHHmm'
    }

    $logPath = '{0}\Temp\MSS\MDESetup' -f $LogFileRootPath

    if (-not (Test-Path -Path $logPath))
    {
        New-Item -Path $logPath -ItemType 'Directory' | Out-Null
    }

    $logFile = '{0}\MDEInstall-{1}.log' -f $logPath, $global:scriptStartTime

    $typeNameMap = @{
        Normal  = 1
        Warning = 2
        Error   = 3
    }

    $logHeader = '<![LOG[{0}]LOG]!>' -f $Message
    $logEntry = @(
        '<time="{0}"' -f (Get-Date -Format 'HH:mm:ss.ffffff')
        'date="{0}"' -f (Get-Date -Format 'M-d-yyyy')
        'component="{0}"' -f ((Get-PSCallStack)[1]).Command
        'context="{0}"' -f [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        'type="{0}"' -f $typeNameMap[$TypeName]
        'thread="{0}"' -f [Threading.Thread]::CurrentThread.ManagedThreadId
        'file="{0}">' -f (Split-Path -Path $MyInvocation.ScriptName -Leaf)
    )

    $content = $logEntry -join ' '
    $content = $logHeader + $content
    Add-Content -Path $logFile -Value $content
}


<#
    .Synopsis
        Writes the MDE activity manifest to the Application log.
    .Parameter Manifest
        The activity manifest.
#>
function Write-MDEEventLog
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [PSCustomObject] $Manifest
    )

    $logName = 'Application'
    $entryType = 'Information'
    $source = 'MSS-MDE'
    $eventID = 3278
    $message = ConvertTo-Jsonl -InputObject $Manifest

    if (-not (Test-EventSourceExists -Source $source))
    {
        New-EventLog -LogName $logName -Source $source -ErrorAction stop
    }

    Write-EventLog -LogName $logName -Source $source -EventId $eventId -EntryType $entryType -Message $message
}



#endregion functions

# Enable newer TLS versions so download doesn't fail on TLS mismatch.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12

switch ($PSCmdlet.ParameterSetName)
{
    'errorCode'
    {
        return (Get-ReturnCode -ErrorCode $ErrorCode)
    }
    'downloadUpdates'
    {
        if (($PSVersionTable).PSVersion -lt [version]'3.0')
        {
            Write-Error 'Update Download function requires PSv3 or greater.'
            return
        }

        Invoke-DownloadUpdates -UpdateMetaData $UpdateMetaData
        return
    }
}

$testEnvironmentReturn = Test-InstallEnvironment

if ($null -ne $testEnvironmentReturn)
{
    exit $testEnvironmentReturn
}

if ($PSCmdlet.ParameterSetName -eq 'config_file')
{
    $parameterSource = 'Configuration File'
    $configurationisValid = Test-ConfigurationFile

    if ($ValidateConfig)
    {
        if ($configurationisValid)
        {
            return 'Valid'
        }

        return 'Invalid - See previous error message.'
    }
    else
    {
        if ($configurationisValid)
        {
            $parameterMessage = Set-ScriptParameters
        }
        else
        {
            return (Get-ReturnCode -ErrorString 'missing_param_in_config')
        }
    }
}
else
{
    $parameterSource = 'Inline Parameters'
    $action, $target, $null = $PSCmdlet.ParameterSetName -split '_'
    $parameterMessage = @(Get-PSCallStack | Where-Object -FilterScript { $_.Command -eq 'Invoke-MDESetup.ps1' })[0].Arguments
}

$manifestParameters = @{
    Action = $action
    Target = $target
}

if ($WorkspaceID)
{
    $manifestParameters.Add('WorkspaceID', $WorkspaceID)
}

if ($FromWorkspaceID)
{
    $manifestParameters.Add('FromWorkspaceID', $FromWorkspaceID)
}

$manifest = Initialize-Manifest @manifestParameters

$shouldRunParameters = @{
    Manifest         = $manifest
    Target           = $target
    MigrateToUnified = $MigrateToUnified
}

if ($FromOrgID)
{
    $shouldRunParameters.Add('FromOrgID', $FromOrgID)
}

$shouldRun = Test-ShouldRun @shouldRunParameters

if ($shouldRun.Result -eq $true)
{
    $manifest.MDE.Add('ScriptVersion', '2506.5.0')

    Write-LogFile -Message ('Starting MDE setup : {0} with {1}' -f '2506.5.0', $parameterSource)
    Write-LogFile -Message ('MDE setup called with arguments: {0}' -f ($parameterMessage -replace '(?<=SASToken=)(.*)(?=,)', '<Redacted>'))
    Write-LogFile -Message ('Running on {0} : {1}' -f $manifest.DeviceNetBIOSName, $manifest.ManifestName)
    Write-LogFile -Message $shouldRun.Message
}
else
{
    Write-Verbose -Message $shouldRun.Message
    exit 0
}

switch ($action)
{
    'onboard'
    {
        $onboardManifestParameters = @{
            Manifest            = $manifest
            Upgrade             = $MigrateToUnified
            EnableMMAFallback   = $EnableMMAFallback
            UpdateDefenderAVAll = $UpdateDefenderAVAll
            RefreshFiles        = $RefreshFiles
        }

        Update-ManifestToOnboard @onboardManifestParameters

        if ($manifest.Error)
        {
            Write-LogFile -Message 'System not ready to Onboard. Resolve previously logged errors and rerun.' -TypeName Error
            break
        }

        $onboardParameters = @{
            CloudType   = $CloudType
            Manifest    = $manifest
            PassiveMode = $PassiveMode
            RemoveAgent = $RemoveAgent
        }

        if ($WorkspaceID)
        {
            $onboardParameters.Add('WorkspaceID', $WorkspaceID)
            $onboardParameters.Add('WorkspaceKey', $WorkspaceKey)
        }

        if ($null -ne $Proxy)
        {
            $onboardParameters.Add('Proxy', $Proxy)
        }

        Invoke-MDEOnboard @onboardParameters
    }

    'offboard'
    {
        $manifestToOffboardParameters = @{
            Manifest     = $manifest
            RefreshFiles = $RefreshFiles
        }

        if ($FromOrgID)
        {
            $manifestToOffboardParameters.Add('FromOrgID', $FromOrgID)
        }

        Update-ManifestToOffboard @manifestToOffboardParameters

        if ($manifest.Error)
        {
            Write-LogFile -Message 'System cannot Offboard. Resolve previously logged errors and rerun.' -TypeName Error
            break
        }

        $offboardParameters = @{
            Manifest    = $manifest
            RemoveAgent = $RemoveAgent
        }

        if ($WorkspaceID)
        {
            $offboardParameters.Add('WorkspaceID', $WorkspaceID)
        }

        Invoke-MDEOffboard @offboardParameters
    }

    'switchorg'
    {
        $switchParameters = @{
            Target              = $target
            CloudType           = $CloudType
            Manifest            = $manifest
            FromOrgID           = $FromOrgID
            PassiveMode         = $PassiveMode
            RemoveAgent         = $RemoveAgent
            EnableMMAFallback   = $EnableMMAFallback
            MigrateToUnified    = $MigrateToUnified
            UpdateDefenderAVAll = $UpdateDefenderAVAll
        }

        if ($StorageAccountName)
        {
            $switchParameters.Add('StorageAccountName', $StorageAccountName)
            $switchParameters.Add('SASToken', $SASToken)
        }

        if ($WorkspaceID)
        {
            $switchParameters.Add('WorkspaceID', $WorkspaceID)
            $switchParameters.Add('WorkspaceKey', $WorkspaceKey)
            $switchParameters.Add('FromWorkspaceID', $FromWorkspaceID)
        }

        if ($null -ne $Proxy)
        {
            $switchParameters.Add('Proxy', $Proxy)
        }

        Invoke-MDESwitch @switchParameters
    }
}

if ($action -eq 'switchorg')
{
    Write-LogFile -Message ('Stopping MDE {0}. Exit Code: {1}' -f $action, $LASTEXITCODE)
    exit $LASTEXITCODE
}
else
{
    if (-not $manifest.Error)
    {
        $manifest.DeviceTag = Get-DeviceTag -AgentType $manifest.MDE.Agent.Type -TagList $TagList
        Set-DeviceTag -DeviceTag $manifest.DeviceTag -Action $action
    }

    $manifest.ReturnCode = Get-ReturnCode -Manifest $manifest -Action $action -RemoveAgent:$RemoveAgent

    if ($manifest.ReturnCode -ne 0)
    {
        $manifest.Error = $true
    }

    if (![string]::IsNullOrEmpty($StorageAccountName) -and ![string]::IsNullOrEmpty($SASToken))
    {
        Send-MDELogFile -StorageAccountName $StorageAccountName -Manifest $manifest -SASToken $SASToken -CloudType $CloudType -Proxy $Proxy
    }

    if ($WriteEventLog)
    {
        Write-MDEEventLog -Manifest $manifest
    }

    Write-LogFile -Message ('Stopping MDE {0}. Exit Code: {1}' -f $action, $manifest.returnCode)

    exit $manifest.ReturnCode
}



# SIG # Begin signature block
# MIIoLQYJKoZIhvcNAQcCoIIoHjCCKBoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBCNV3ld9xO2SzW
# 22eQNStueY2fWN0lDSPmOs0Y5+jYkKCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIqyuZWX/gScwgRuElsdpJ2t
# Mhht6qzihTurzf39LvZsMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAbBimLw9GvJXhzqAc+gg0zO3YdZeUl3uKbfBNtJHyDKRDLuF6Hdud8KDt
# MHQkgahb6y+uHNvzWOCMQVSu6TNqm3e4QiXmKRL5Fai/IHEm8a5uByVait4WqFN2
# Q9u+GDD4yEufYySGpK+yW8KFhtrpmULqRHq10rVvxxngjV0B7RBX8fXONAaL29iv
# HfACOij7VIhJCSCOmctTD+LgyHfjinsDtcB5MrdjLP1sYc6bzuenVIMJ2Argh8US
# nH5q5VZmghPjGT49ancvunBWKpjI/SO5sGAC3csEhT/9Rl5twCq/MxxbpQd1kf1O
# oagWAJfcWOse8aJ7hsKA5h6kr8sV5aGCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCC
# F38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAlJ/2tU1ax9CvPFUWBNu0UVF40cSsz4Y5N1d10umqoPQIGaEsz79SO
# GBMyMDI1MDYxODE1MDkxNi4xNjNaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHtMIIHIDCCBQigAwIBAgITMwAAAgTY4A4HlzJYmAABAAACBDANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQy
# NDdaFw0yNjA0MjIxOTQyNDdaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDw3Sbcee2d66vkWGTIXhfGqqgQGxQXTnq44XlUvNzF
# St7ELtO4B939jwZFX7DrRt/4fpzGNkFdGpc7EL5S86qKYv360eXjW+fIv1lAqDD3
# 1d/p8Ai9/AZz8M95zo0rDpK2csz9WAyR9FtUDx52VOs9qP3/pgpHvgUvD8s6/3KN
# ITzms8QC1tJ3TMw1cRn9CZgVIYzw2iD/ZvOW0sbF/DRdgM8UdtxjFIKTXTaI/bJh
# sQge3TwayKQ2j85RafFFVCR5/ChapkrBQWGwNFaPzpmYN46mPiOvUxriISC9nQ/G
# rDXUJWzLDmchrmr2baABJevvw31UYlTlLZY6zUmjkgaRfpozd+Glq9TY2E3Dglr6
# PtTEKgPu2hM6v8NiU5nTvxhDnxdmcf8UN7goeVlELXbOm7j8yw1xM9IyyQuUMWko
# rBaN/5r9g4lvYkMohRXEYB0tMaOPt0FmZmQMLBFpNRVnXBTa4haXvn1adKrvTz8V
# lfnHxkH6riA/h2AlqYWhv0YULsEcHnaDWgqA29ry+jH097MpJ/FHGHxk+d9kH2L5
# aJPpAYuNmMNPB7FDTPWAx7Apjr/J5MhUx0i07gV2brAZ9J9RHi+fMPbS+Qm4AonC
# 5iOTj+dKCttVRs+jKKuO63CLwqlljvnUCmuSavOX54IXOtKcFZkfDdOZ7cE4DioP
# 1QIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFBp1dktAcGpW/Km6qm+vu4M1GaJfMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQBecv6sRw2HTLMyUC1WJJ+FR+DgA9Jkv0lG
# sIt4y69CmOj8R63oFbhSmcdpakxqNbr8v9dyTb4RDyNqtohiiXbtrXmQK5X7y/Q+
# +F0zMotTtTpTPvG3eltyV/LvO15mrLoNQ7W4VH58aLt030tORxs8VnAQQF5BmQQM
# Oua+EQgH4f1F4uF6rl3EC17JBSJ0wjHSea/n0WYiHPR0qkz/NRAf8lSUUV0gbIMa
# wGIjn7+RKyCr+8l1xdNkK/F0UYuX3hG0nE+9Wc0L4A/enluUN7Pa9vOV6Vi3BOJS
# T0RY/ax7iZ45leM8kqCw7BFPcTIkWzxpjr2nCtirnkw7OBQ6FNgwIuAvYNTU7r60
# W421YFOL5pTsMZcNDOOsA01xv7ymCF6zknMGpRHuw0Rb2BAJC9quU7CXWbMbAJLd
# Z6XINKariSmCX3/MLdzcW5XOycK0QhoRNRf4WqXRshEBaY2ymJvHO48oSSY/kpuY
# vBS3ljAAuLN7Rp8jWS7t916paGeE7prmrP9FJsoy1LFKmFnW+vg43ANhByuAEXq9
# Cay5o7K2H5NFnR5wj/SLRKwK1iyUX926i1TEviEiAh/PVyJbAD4koipig28p/6HD
# uiYOZ0wUkm/a5W8orIjoOdU3XsJ4i08CfNp5I73CsvB5QPYMcLpF9NO/1LvoQAw3
# UPdL55M5HTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQ
# MIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjk2MDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQC6
# PYHRw9+9SH+1pwy6qzVG3k9lbqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6/zyNTAiGA8yMDI1MDYxODA4MDcx
# N1oYDzIwMjUwNjE5MDgwNzE3WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDr/PI1
# AgEAMAoCAQACAgqlAgH/MAcCAQACAhLrMAoCBQDr/kO1AgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQELBQADggEBAHtus8n13RLicbkjgj/49HJQb2hdT31GIgfU9qRIviaX
# mGFdzk10ahQKyIhKdzh5ry/+jJ33PjNvxLE/c87OUtdpCiEFduxO4WIwxZ9m0L36
# FmRJXBRnNQIZ212tKNu2u7Y948pjxHRK+rueTW2tO3H/njbclQVLSyHiV5YnRgaB
# GScOB00txgQqPloumAgokcgpu+VQKzzhEmEijKJwKxknFN1ovelZX/ABSmNza4/k
# IMqBC2UlOtJbrOXvLxDP9VuiWYZD/XgF0DPc+3h51nMjpslIhwAYd1DJ8CYhsHLJ
# Vmwds/S8jmtvk78GH6QsIeha/qetv+wVrTOjc5aOqrsxggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAgTY4A4HlzJYmAABAAAC
# BDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCCkslATpu802BtUhtEzU9XCCkbrkPmcJWbuk78aaMEW
# yjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIPnteGX9Wwq8VdJM6mjfx1GE
# Jsu7/6kU6l0SS5rcebn+MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAIE2OAOB5cyWJgAAQAAAgQwIgQgrcEQ9X66TUbX1c/kq83MCsZY
# NlHiPF+TdPmiZigxgsQwDQYJKoZIhvcNAQELBQAEggIACs57+mP2wY4T6t/GIK0B
# AmY7NB7lUTBJdI7MUNP/pYvsv42MvwkursK/fNXKeqExlISbQPiu/cv+51sYr0Aq
# JQTc+wXWa7YECs1le3yo2eJ/uKFhx3/HxqKX4QXQsnRFgxUDjOANvJGNk4XCfyI9
# k0j6qT9pL75Tp3IuDQtSVgCrq+DGxrPCOyxYsZXR5nGDyG6fLWfjLRybSaYMXPb3
# 6IwM6ymV3Pf8lwO3VoGY1fpxhqRMNFk/APZW/anG5vH843wkIQAvyPWZnCr1Q+vW
# YRup2/vVzPTxCsSQOmmclVMObR1b4bfABpkW+MhNLVWuhzSjipO8k8j9hW7lAG1w
# 0zEGQecy7tYtgH35vvzrAz6dSCukmtaWHNlcwaUWdF+M/taZrymXI/ENc13zavXT
# 66Df+qGtpO1QCCfZo5XRw17rGKkW2gfb5pivIzvnLbU/0yRYu3Xa7/yh7HijpQQI
# +tNOyGWXvLu1ZjwJMwedU9OHwVuMfxIvZnCQD00NKONkFhnsfQwYrbfa1DBRNwF4
# loYRMHJMkO2wrzC3TEeYPoIUO9BRfUnEdv3I1/NdVr/MoobxhenTxkf5TFi5HIVH
# kWqExCthaGAjtAJgfwJfJFwjn8UqYMyVQHze889YME0aXWeINJ8h2suzaXHlJbL5
# k+jre5yqVVz6Koyol3YAw0s=
# SIG # End signature block
